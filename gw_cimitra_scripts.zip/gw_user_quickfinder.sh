#!/bin/bash
###########################################
# gw_user_quickfinder.sh                  #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# Rebuilding the QuickFinder Indexes for one user

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare GW_POA_HTTP_USER_NAME=""
declare GW_POA_HTTP_USER_PASSWORD=""

declare -i GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=0

declare -i USER_IN_SET=0
declare -i NEW_PASSWORD_IN_SET=0

declare -i POA_HTTP_PORT_IN_SET=0
declare -i POA_HTTP_ADDRESS_IN_SET=0
declare -i POA_HTTP_INFORMATION_SET=0



while getopts "a:u:p:hvw:" opt; do
  case ${opt} in
    a) POA_HTTP_ADDRESS_IN="$OPTARG"
	POA_HTTP_ADDRESS_IN_SET=1
	;;
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
    w) POA_HTTP_PORT_IN="$OPTARG"
	POA_HTTP_PORT_IN_SET=1
	;;
   
  esac
done

### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise User Last Login Query"
echo ""
echo "Script usage: $0 [options]"
echo ""
echo "Example:      $0  -p <post office> -u <GroupWise userid>"
echo ""
echo "Verbose Mode: $0 -v  -p <post office> -u <GroupWise userid>"
echo ""
echo "Help:         $0 -h"
echo ""
}

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
	CURRENT_DIR=`pwd`
	GW_SCRIPT_SETTINGS_FILE="${CURRENT_DIR}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=\"1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then

CURRENT_DIR=`pwd`
GW_SCRIPT_EXCLUDE_FILE="${CURRENT_DIR}/exclude_gw.cfg"

fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then

echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}

fi

}

function PROCESS_HTTP_SETTINGS_FILES()
{

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
	CURRENT_DIR=`pwd`
	GW_SCRIPT_SETTINGS_FILE="${CURRENT_DIR}/settings_gw.cfg"
fi


declare -i GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=2
source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL -eq 2 ]
then
echo "GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=\"1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_USER_NAME=\"poa_http_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_USER_PASSWORD=\"poa_http_user_password\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
echo "Configure the GW_POA_HTTP* variables"
echo ""
exit 1
fi

if [ $GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL -eq 0 ]
then
POST_OFFICE_IN_LOWER=`echo "${POST_OFFICE_IN}" | tr [A-Z] [a-z]`
POA_HTTP_CONFIGURATION_FILE="${CURRENT_DIR}/${POST_OFFICE_IN_LOWER}.poa.cfg"

declare -i POA_HTTP_CONFIGURATION_FILE_EXISTS=`ls ${POA_HTTP_CONFIGURATION_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`
	
	if [ $POA_HTTP_CONFIGURATION_FILE_EXISTS -eq 1 ]
	then
	echo "GW_POA_HTTP_USER_NAME=\"poa_http_user\"" >> ${POA_HTTP_CONFIGURATION_FILE}
	echo "GW_POA_HTTP_USER_PASSWORD=\"poa_http_user_password\"" >> ${POA_HTTP_CONFIGURATION_FILE}
	echo ""
       echo "Please configure the GroupWise POA Settings file: ${POA_HTTP_CONFIGURATION_FILE}"
	echo ""
	echo "Configure the GW_POA_HTTP* variables"
	echo ""
	exit 1
	else

	GW_POA_HTTP_USER_NAME='poa_http_user'
	# Read the POA_HTTP_CONFIGURATION_FILE file
	source ${POA_HTTP_CONFIGURATION_FILE}

		if [[ ${GW_POA_HTTP_USER_NAME} = 'poa_http_user' ]]
		then
		echo ""
       	echo "Please configure the GroupWise POA Settings file: ${POA_HTTP_CONFIGURATION_FILE}"
		echo ""
		echo "Configure the GW_POA_HTTP* variables"
		echo ""
		exit 1
		fi

	fi
else

GW_POA_HTTP_USER_NAME='poa_http_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}
	if [[ ${GW_POA_HTTP_USER_NAME} = 'poa_http_user' ]]
	then
	echo ""
	echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
	echo ""
	echo "Configure the GW_POA_HTTP* variables"
	echo ""
	exit 1
	fi



fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo "Error authenticating to GroupWise Admnistration Service"
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "Error: Exclusions Check File does not exist"
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo "Error: Please properly configure exclude group name"
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo "Error: Please properly configure exclude group's post office name"
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo "Error: Please properly configure exclude group's domain name"
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo "Error getting exclude group information"
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo "Error getting exclude group membership count[1]"
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo "Error getting exclude group membership count [2]"
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo "Error getting exclude group membership count [3]"
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo "Error getting exclude group membership count [4]"
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}


### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+POST_OFFICE_IN_SET

if [ $ALL_SET -ne 2 ]
then
SHOW_HELP
echo "NOTE: Insufficient Input To Run Script"
exit 1
fi
}


### Primary Function###
function REQUEST_QUICKFINDER_INDEX_REBUILD()
{

declare -i POA_HTTP_PORT_IN_SET=0
declare -i POA_HTTP_ADDRESS_IN_SET=0
declare -i POA_HTTP_INFORMATION_SET=0

let POA_HTTP_INFORMATION_SET=POA_HTTP_PORT_IN_SET+POA_HTTP_ADDRESS_IN_SET

if [ $POA_HTTP_INFORMATION_SET -ne 2 ]
then

BASE_REST_URL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="${BASE_REST_URL}/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

POA_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/poas/poa"}'`

POA_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${POA_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "${POA_OBJECT}" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

POA_HTTP_IP_ADDRESS=`cat ${TEMP_FILE_TWO} | grep ipAddress | awk -F : '{printf $2}'`

POA_HTTP_PORT=`cat ${TEMP_FILE_TWO} | grep httpPort | awk -F : '{printf $2}'`

rm ${TEMP_FILE_ONE} 

rm ${TEMP_FILE_TWO}

fi


SEARCHURL="${BASE_REST_URL}/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASE_REST_URL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`

declare -i EXIT_STATUS=`echo $?`


if [ $EXIT_STATUS -eq 0 ]
then
:
else
echo "Cannot Determine Information For: ${USERID_IN}"
exit 1
fi


USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASE_REST_URL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

FID=`grep "fileId:" ${TEMP_FILE_TWO} | awk -F : '{printf $2}'`

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO}  2> /dev/null


if [ $POA_HTTP_ADDRESS_IN_SET -eq 0 ]
then
GW_POA_HTTP_ADDRESS="${POA_HTTP_IP_ADDRESS}"
else
GW_POA_HTTP_ADDRESS="${POA_HTTP_ADDRESS_IN}"
fi

if [ $POA_HTTP_PORT_IN_SET -eq 0 ]
then
GW_POA_HTTP_PORT="${POA_HTTP_PORT}"
else
GW_POA_HTTP_PORT="${POA_HTTP_PORT_IN}"
fi

BASE_POA_URL="https://${GW_POA_HTTP_ADDRESS}:${GW_POA_HTTP_PORT}/cfg/0"

QUICKFINDER_DATA_ONE="qf_set=Enabled&qfopt_level=Unlimited&qfopt_pre=yes&qfopt_lib=yes&qfopt_user=yes&qfopt_beg='$FID'&qfopt_end='$FID'&qf_thread=1&dca_maxtime=300&dca_maxsize=20480&qf_action=1"

{
curl -i -k --user ${GW_POA_HTTP_USER_NAME}:${GW_POA_HTTP_USER_PASSWORD} ${BASE_POA_URL} -H "Content-Type: application/x-www-form-urlencoded" -d ${QUICKFINDER_DATA_ONE}
} 2> /dev/null 1> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
:
else
echo "Cannot Log into POA HTTP Console"
exit 1
fi

QUICKFINDER_DATA="qf_set=Enabled&qfopt_level=Unlimited&qfopt_pre=yes&qfopt_lib=yes&qfopt_user=yes&qfopt_beg='$FID'&qfopt_end='$FID'&qf_thread=1&dca_maxtime=300&dca_maxsize=20480&qf_action=1&submit=Submit"


SUBMIT_QUICKFINDER_REBUILD_REQUEST=`curl ${CURL_OUTPUT_MODE} -i -k --user ${GW_POA_HTTP_USER}:${GW_POA_HTTP_PASSWORD} ${BASE_POA_URL} -H "Content-Type: application/x-www-form-urlencoded" -d ${QUICKFINDER_DATA}`

echo ""
echo "Successfully submitted QuickFinder Indexing Rebuild for USERID: ${USERID_IN}, FID: ${FID}"
echo ""





}


main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

CONFIRM_CORRECT_INPUT
PROCESS_SETTINGS_FILES
PROCESS_HTTP_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
PROCESS_EXCLUSIONS
GET_EXCLUDE_GROUP_MEMBERSHIP
REQUEST_QUICKFINDER_INDEX_REBUILD
}

main





#!/bin/bash
###########################################
# gw_user_msgr_last.sh                    #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# Allows for a GroupWise Messenger Account Last Name to be Changed

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"

declare -i USER_IN_SET=0
declare -i DOMAIN_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i FIRST_NAME_IN_SET=0
declare -i LAST_NAME_IN_SET=0
declare -i VERBOSE_MODE=0
declare -i CREDENTIAL_IN_SET=0
declare LAST_NAME_IN=""
declare FIRST_NAME_IN=""
declare -i POLICY_ID_IN_SET=0


declare DOMAIN_IN=""
declare -i OBJECT_VISIBILITY_INPUT_SET=0
declare -i OBJECT_VISIBILITY_INPUT=4
declare OBJECT_VISIBILITY="SYSTEM"

while getopts "u:i:d:p:f:l:c:o:hv" opt; do
  case ${opt} in
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    d) DOMAIN_IN="$OPTARG"
	DOMAIN_IN_SET=1
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;
    f) FIRST_NAME_IN="$OPTARG"
	FIRST_NAME_IN_SET=1
      ;;
    i) LAST_NAME_IN="$OPTARG"
	LAST_NAME_IN_SET=1
      ;;
    c) CREDENTIAL_IN="$OPTARG"
	CREDENTIAL_IN_SET=1
      ;;
    o) OBJECT_VISIBILITY_INPUT="$OPTARG"
	OBJECT_VISIBILITY_INPUT_SET=1
      ;;
    h) SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
	VERBOSE_MODE=1;
      ;;
  esac
done


SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

function DETERMINE_VISIBILITY()
{

case $OBJECT_VISIBILITY_INPUT in
1)
OBJECT_VISIBILITY="NONE"
;;
2)
OBJECT_VISIBILITY="POST_OFFICE"
;;
3)
OBJECT_VISIBILITY="DOMAIN"
;;
4)
OBJECT_VISIBILITY="SYSTEM"
;;
esac

}



### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise Messenger Account Last Name Rename Script"
echo ""
echo "Script usage: $0 [options]"
echo ""
echo ""
echo "Switches:     $0 -u <messenger userid> -l <Last name>"
echo ""
echo "Example:      $0 -u jdoe -l Smith"
echo ""
echo "Verbose Mode: $0 -v ..."
echo ""
echo "Help:         $0 -h"
echo ""
}


### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+LAST_NAME_IN_SET

if [ $ALL_SET -ne 2 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}




LAST_NAME_IN=`echo "$@" | awk -F \-i '{printf $2}' | awk -F \-i '{printf $1}'`

LAST_NAME_IN="$(echo -e "${LAST_NAME_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"


declare -i NUMBER_OF_LN_SPACES=`echo ${LAST_NAME_IN} | tr -cd ' \t' | wc -c`


if [ $NUMBER_OF_LN_SPACES -gt 0 ]
then

declare -i LAST_NAME_SET_TEST=`echo "$@" | grep -c '\-l'`


	if [ $LAST_NAME_SET_TEST -eq 1 ]
	then
	
	LAST_NAME_IN_LENGTH=${#LAST_NAME_IN}

		if [ $LAST_NAME_IN_LENGTH -lt 1 ]
		then
		echo ""
		echo "NOTE: Last name not entered"
		else
		LAST_NAME_IN_SET=1
		fi
	fi
else

declare -i LAST_NAME_SWITCH_USED=`echo "$@" | grep -c '\-i'`

	if [ $LAST_NAME_SWITCH_USED -eq 1 ]
	then

	LAST_NAME_IN_LENGTH=${#LAST_NAME_IN}

		if [ $LAST_NAME_IN_LENGTH -lt 1 ]
		then
		echo ""
		echo "NOTE: Last name not entered"
		else
		LAST_NAME_IN_SET=1
		fi
		
	else
	:
	fi

fi



USERID_IN=`echo "$@" | awk -F \-u '{printf $2}' | awk -F \-i '{printf $1}'`

USERID_IN="$(echo -e "${USERID_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"


declare -i USERID_IN_SET_TEST=`echo "$@" | grep -c '\-u'`



if [ $USERID_IN_SET_TEST -eq 1 ]
then
	
USERID_IN_LENGTH=${#USERID_IN}

	if [ $USERID_IN_LENGTH -lt 1 ]
	then
	echo ""
	echo "Error: Userid not entered"
	echo ""
	SHOW_HELP
	exit 1
	else
	USERID_IN_SET=1
	fi
fi

CONFIRM_CORRECT_INPUT

DEBUG_INFO()
{
echo "CREDENTIAL_IN_SET = $CREDENTIAL_IN_SET"
echo "CREDENTIAL_IN = $CREDENTIAL_IN"
echo "FIRST_NAME_IN_SET = $FIRST_NAME_IN_SET"
echo "FIRST_NAME_IN = $FIRST_NAME_IN"
echo "LAST_NAME_IN_SET = $LAST_NAME_IN_SET"
echo "LAST_NAME_IN = $LAST_NAME_IN"
echo "USERID_IN_SET = $USERID_IN_SET"
echo "USERID_IN = $USERID_IN"
}

if [ $VERBOSE_MODE -eq 1 ]
then
DEBUG_INFO
fi

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}

function GET_DOMAIN()
{

if [ $DOMAIN_IN_SET -eq 1 ]
then
return
fi
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

DOMAIN_IN=`grep "id:USER." ${TEMP_FILE_TWO} | grep -i ".${POST_OFFICE_IN}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

DOMAIN_IN=`echo "${DOMAIN_IN}" | tr [A-Z] [a-z]`

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

}

function GET_USER_FULL_NAME()
{
echo ""
#-- Build the base url for admin service
URL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/messengers/MessengerService/users/${USERID_IN}"

{
TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
return
fi

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

LAST_NAME=`cat "${TEMP_FILE_TWO}" | grep -A 4 "surnameProperty" | tail -1 | awk -F ":" '{printf $2}'`

FIRST_NAME=`cat "${TEMP_FILE_TWO}" | grep -A 4 "givenNameProperty" | tail -1 | awk -F ":" '{printf $2}'`

echo "FULL NAME:   ${FIRST_NAME} ${LAST_NAME}"
echo ""

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null
 
}


### Primary Function for Account CREATION ###
function LAST_NAME_CHANGE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/messengers/MessengerService/users/${USERID_IN}"

USERDATA='{"nameProperty": "'${USERID_IN}'", "surnameProperty" : { "value" : "'${LAST_NAME_IN}'" }}'

{
curl -f -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -H "content-type:application/json" -X PUT --data "$USERDATA" $BASEURL
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`


if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "GroupWise Messenger Account Last Name Changed: ${USERID_IN} | ${LAST_NAME_IN}"
echo ""
else
echo ""
echo "GroupWise Messenger Account Last Name NOT Changed: ${USERID_IN}"
echo ""
fi
}



main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

PROCESS_SETTINGS_FILES
PROCESS_EXCLUSIONS
CHECK_GWADMIN_SERVICE
GET_EXCLUDE_GROUP_MEMBERSHIP
CONFIRM_CORRECT_INPUT
GET_USER_FULL_NAME
LAST_NAME_CHANGE
GET_USER_FULL_NAME
}

main




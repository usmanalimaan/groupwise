#!/bin/bash

###########################################
# gw_user_first_name_change.sh            #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.5                            #
# Modify date: 2/15/2020                  #
###########################################
# Allows for Changing a GroupWise User's First Name

declare INPUT_TYPE_TEXT="First Name"
declare GROUPWISE_OBJECT_NAME="givenName"
declare LDAP_OBJECT_NAME="givenName"
declare HELP_EXAMPLE="Jane"
declare -i ALLOW_MULTIPLE_WORD_INPUT=1

declare INPUT_IN=""
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0

declare FULL_NETWORK_ID=""
declare -i SKIP_GROUPWISE_USER_OBJECT_CHANGE=0
declare GW_SCRIPT_SETTINGS_FILE=""

declare -i USER_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i INPUT_IN_SET=0
declare -i SKIP_LDAP_ASSOCIATION_CHECK=0

while getopts "u:p:i:shv" opt; do
  case ${opt} in
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;
    i) INPUT_IN="$OPTARG"
	INPUT_IN_SET=1
      ;;
    s) SKIP_LDAP_ASSOCIATION_CHECK=1
      ;;
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise User ${INPUT_TYPE_TEXT} Change Script"
echo ""
echo "Script usage:      $0 [options]"
echo ""
echo "Example:           $0 -p <post office> -u <GroupWise userid> -i <${INPUT_TYPE_TEXT}>"
echo ""
echo "Example:           $0 -p po1 -u jdoe -i ${HELP_EXAMPLE}"
echo ""
echo "Verbose Mode:      $0 -v -p <post office> -u <GroupWise userid> -i <${INPUT_TYPE_TEXT}>"
echo ""
echo "Skip LDAP:         $0 -s ... | Skip user association check in eDirectory�"
echo ""
echo "Help:              $0 -h"
echo ""
}


if [ $ALLOW_MULTIPLE_WORD_INPUT -eq 1 ]
then
INPUT_IN=`echo "$@" | awk -F \-i '{printf $2}' | awk -F \-i '{printf $1}'`

INPUT_IN="$(echo -e "${INPUT_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"


declare -i NUMBER_OF_INPUT_SPACES=`echo ${INPUT_IN} | tr -cd ' \t' | wc -c`


	if [ $NUMBER_OF_INPUT_SPACES -gt 0 ]
	then

	declare -i INPUT_SET_TEST=`echo "$@" | grep -c '\-i'`


		if [ $INPUT_SET_TEST -eq 1 ]
		then
	
		INPUT_IN_LENGTH=${#INPUT_IN}

			if [ $INPUT_IN_LENGTH -lt 1 ]
			then
			echo ""
			echo "Error: ${INPUT_TYPE_TEXT} not entered"
			echo ""
			exit 1
			else
			INPUT_IN_SET=1
			fi
		fi
	else

		declare -i INPUT_SWITCH_USED=`echo "$@" | grep -c '\-i'`

		if [ $INPUT_SWITCH_USED -eq 1 ]
		then

		INPUT_IN_LENGTH=${#INPUT_IN}

			if [ $INPUT_IN_LENGTH -lt 1 ]
			then
			echo ""
			echo "Error: ${INPUT_TYPE_TEXT} not entered"
			echo ""
			exit 1
			else
			INPUT_IN_SET=1
			fi
		
		else
		:
		fi

	fi

fi


### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function PROCESS_EDIR_SETTINGS()
{

GW_ADMIN_USER='admin_level_user'
declare -i GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=0
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


if [[ ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -eq 0 ]]
then
echo "GW_EDIR_ADMIN_USER=\"cn=admin,o=cimitra\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_ADMIN_PASSWORD=\"eDirLetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS=\"172.0.0.1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=\"389\"" >> ${GW_SCRIPT_SETTINGS_FILE}
fi

}


function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error: Cannot authenticate to GroupWise Administration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}


### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+POST_OFFICE_IN_SET+INPUT_IN_SET

if [ $ALL_SET -ne 3 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}


function SYNC_GROUPWISE_USER_OBJECT()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Cannot establish connection to GroupWise Admin Service"
echo ""
exit 1
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

USER_DOMAIN=`echo "${USER_OBJECT}" | grep -Po '"domainName":"\K[^"]*'`

SYNC_URL="$BASEURL/domains/${USER_DOMAIN}/postoffices/${POST_OFFICE_IN}/users/${USERID_IN}/directorylink/sync"

{
DO_SYNC=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X POST ${SYNC_URL}` 1> /dev/null
} 1> /dev/null 2> /dev/null

}


function GET_GROUPWISE_EDIR_USER_OBJECT()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Cannot establish connection to GroupWise Admin Service"
echo ""	
exit 1
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

declare -i USER_HAS_LDAP_TREE=`echo "${USER_OBJECT}" | grep -c "directoryId"`


if [ $USER_HAS_LDAP_TREE -eq 0 ]
then
echo ""
echo "Error: Cannot discover eDirectory tree for GroupWise account ${USERID_IN}"
echo ""
exit 1
fi

declare -i CN_EXISTS=`echo "${USER_OBJECT}" | grep -cPo '"ldapDn":"\K[^"]*'`

if [ $CN_EXISTS -eq 1 ]
then
FULL_NETWORK_ID=`echo "${USER_OBJECT}" | grep -Po '"ldapDn":"\K[^"]*'`
else
declare -i USER_HAS_NETWORK_ID=`echo "${USER_OBJECT}" | grep -c "networkId"`

	if [ $USER_HAS_NETWORK_ID -eq 1 ]
	then
	NETWORK_ID_ONE=`echo "${USER_OBJECT}" | grep -Po '"networkId":"\K[^"]*'`
	NETWORK_ID_TWO=`echo "${NETWORK_ID_ONE}" | sed -r 's/(.*)\./\1,o=/'`
	NETWORK_ID_THREE=`echo "${NETWORK_ID_TWO}" | sed 's/\./,ou=/g'`
	FULL_NETWORK_ID="cn=${NETWORK_ID_THREE}"
	else
	echo ""
	echo "Error: Cannot discover network ID for GroupWise account ${USERID_IN}"
	echo ""	
	exit 1
	fi

fi

}


### Primary Function for User Attribute Edit ###
function CHANGE_USER_EDIR_ATTRIBUTE()
{
# --- Create ldif data for the setting change

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.ldif"

echo "dn: ${FULL_NETWORK_ID}" 1> ${TEMP_FILE_ONE}
echo "changetype: Modify" 1>> ${TEMP_FILE_ONE}
echo "replace: ${LDAP_OBJECT_NAME}" 1>> ${TEMP_FILE_ONE}
echo "${LDAP_OBJECT_NAME}: ${INPUT_IN}" 1>> ${TEMP_FILE_ONE}

source ${GW_SCRIPT_SETTINGS_FILE}
# --- Now use ldapmodify to change the value

{
ldapmodify -x -h ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -w $GW_EDIR_ADMIN_PASSWORD -D $GW_EDIR_ADMIN_USER -f ${TEMP_FILE_ONE}
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

rm ${TEMP_FILE_ONE} 1> /dev/null 2> /dev/null


if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} Changed to: ${INPUT_IN}"
echo ""
SYNC_GROUPWISE_USER_OBJECT
else
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} NOT Changed to: ${INPUT_IN}"
echo ""
fi
}


function CHECK_FOR_LDAP_DIRECTORY()
{

if [ $SKIP_LDAP_ASSOCIATION_CHECK -eq 1 ]
then
return
fi

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

declare -i LDAP_DIRECTORY_SPECIFIED=`echo ${USER_OBJECT} | grep -c "directoryId"`

if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
then
PROCESS_EDIR_SETTINGS
GET_GROUPWISE_EDIR_USER_OBJECT
CHANGE_USER_EDIR_ATTRIBUTE
SKIP_GROUPWISE_USER_OBJECT_CHANGE=1
fi

}

### Primary Function for User GroupWise Object Change ###
function CHANGE_USER_GROUPWISE_ATTRIBUTE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"${GROUPWISE_OBJECT_NAME}\":\"${INPUT_IN}\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

# --- Now use curl to change the value

{
curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data "$DATA"
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} Changed to: ${INPUT_IN}"
echo ""
else
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} NOT Changed to: ${INPUT_IN}"
echo ""
fi


}

main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
CONFIRM_CORRECT_INPUT
PROCESS_EXCLUSIONS
GET_EXCLUDE_GROUP_MEMBERSHIP
CHECK_FOR_LDAP_DIRECTORY
if [ $SKIP_GROUPWISE_USER_OBJECT_CHANGE -eq 0 ]
then
CHANGE_USER_GROUPWISE_ATTRIBUTE
fi

}

main





#!/bin/bash

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

INTEGRATE_SCRIPT="integrate.sh"
declare -i INTEGRATE_SCRIPT_EXISTS=`test -f ${SCRIPT_PATH}/${INTEGRATE_SCRIPT} ; echo $?`



if [ $INTEGRATE_SCRIPT_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${SCRIPT_PATH}/${INTEGRATE_SCRIPT} Does Not Exist"
echo ""
exit 1
fi

POST_OFFICE_IN=$1

PO_IN=`echo ${POST_OFFICE_IN// /}`
if [ -z "$PO_IN" ]
then
echo ""
echo "Error:   Specify the Post Office Name to Integrate"
echo "" 
echo "Example: $0 po1"
echo ""
exit 1
fi

echo ""
echo "Removing Cimitra Integration With Post Office: ${PO_IN}"
echo ""

cd ${SCRIPT_PATH}


/bin/bash ./${INTEGRATE_SCRIPT} -u -p ${PO_IN} 1> /dev/null 2> /dev/null & 1> /dev/null 2> /dev/null


exit 0

#!/bin/bash
###########################################
# gw_cimitra_configur.sh                  #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 3/3/2020                   #
###########################################
# Cimitra/GroupWise Integration Setup script

declare -i VAR_COUNTER=0
declare -i ALLOW_GROUP_CREATION=0
declare -i ALLOW_EXCLUDE_GROUP_ENABLEMENT=1

declare -i SHOW_HELP_SCREEN=0
declare CURL_OUTPUT_MODE="--silent"
declare -i SKIP_CONNECTIVITY_CHECKS=0

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

declare CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"
declare CIMITRA_SERVER_PORT="443"
declare CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
declare CIMITRA_SERVER_ADMIN_PASSWORD="changeme"

declare FUNCTION_IN_SET=0

while getopts "f:chmtvs" opt; do
  case ${opt} in
    c) CONFIGURE_SETTINGS="0"
      ;;
    h) SHOW_HELP_SCREEN=1
      ;;
    f) FUNCTION_IN="$OPTARG"
	FUNCTION_IN_SET=1
      ;;
    t) TEST_CONNECTIVITY="1"
      ;;
    s) SKIP_CONNECTIVITY_CHECKS="1"
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


FUNCTION_IN="$1"
VAR1="$2"
VAR2="$3"
VAR3="$4"
VAR4="$5"
VAR5="$6"
VAR6="$7"
VAR7="$8"
VAR8="$9"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Setup Script"
echo ""
echo "Script usage:      $0 [options]"
echo ""
echo "Example:           $0"
echo ""
echo "Configure Mode:    $0 -c or $0 configure"
echo ""
echo "Test Connectivity: $0 -t or $0 test"
echo ""
echo "Skip Connectivity Testing: $0 -s"
echo ""
echo "Verbose Mode:      $0 -v"
echo ""
echo "Help:              $0 -h or $0 -h "
echo ""
}

function CALL_EXIT()
{
EXIT_CODE=$1
exit ${EXIT_CODE}
}

declare -i FIRST_INPUT_IS_HELP=`echo "$1" | grep -ic "help"`

if [ $FIRST_INPUT_IS_HELP -gt 0 ]
then
SHOW_HELP
exit 0
fi


function TEXT_EDITOR_REPLACE()
{
# TEXT_EDITOR_REPLACE "SETTING_NAME" "${SETTING_VARIABLE}" "$CONFIG_FILE"

declare -i ARG_ONE_EMPTY=`echo "$1" | wc -c`
declare -i ARG_TWO_EMPTY=`echo "$2" | wc -c`
declare -i ARG_THREE_EMPTY=`echo "$3" | wc -c`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

if [ $ARG_ONE_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_TWO_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_THREE_EMPTY -lt 2 ]
then
return
else
:
fi

touch $3
declare -i LINES_PRIOR_TO_REMOVAL=`grep -c "=" $3`
declare -i EQUALS_EXIST=`grep -c "=" $3`

egrep -v "${1}=" $3 | sed '/^[[:space:]]*$/d' > ${TEMP_FILE_ONE}


declare -i LINES_AFTER_REMOVAL=`grep -c "=" ${TEMP_FILE_ONE}`
declare -i DIFFERENCE_OF_LINES_REMOVED=0
let DIFFERENCE_OF_LINES_REMOVED=LINES_PRIOR_TO_REMOVAL-LINES_AFTER_REMOVAL

if [ $DIFFERENCE_OF_LINES_REMOVED -gt 3 ]
then
rm ${TEMP_FILE_ONE}
echo ""
date
echo "It seems something is wrong, this setting change will not be made"
echo ""
fi


rm $3
mv ${TEMP_FILE_ONE} $3 
echo "${1}=\"${2}\"" >> $3

} # 2> /dev/null

function TEXT_EDITOR_CONFIRM()
{

declare -i ARG_ONE_EMPTY=`echo "$1" | wc -c`
declare -i ARG_TWO_EMPTY=`echo "$2" | wc -c`
declare -i ARG_THREE_EMPTY=`echo "$3" | wc -c`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

if [ $ARG_ONE_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_TWO_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_THREE_EMPTY -lt 2 ]
then
return
else
:
fi

touch $3

declare -i LINE_EXISTS=`grep -wc "$2" $3`


if [ $LINE_EXISTS -gt 0 ]
then
return 0
fi

TEXT_EDITOR_REPLACE "$1" "$2" "$3"

}

function CHECK_GWADMIN_SERVICE()
{
if [ $SKIP_CONNECTIVITY_CHECKS -eq 1 ]
then
return 0
fi

echo ""
echo "Process: Checking GroupWise Authentication Credentials"

declare -i CONNECTION_VERBOSITY=$1

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_ADMIN_SERVICE_ADDRESS="${LOCAL_IP}"
GW_ADMIN_SERVICE_PORT="9710"
GW_ADMIN_USER="admin"
GW_ADMIN_PASSWORD="LetMeInOk"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

URL="${BASEURL}/${ENDPOINT}"

USER="${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD}"

CONTENT_TYPE='"Content-Type: application/json"'

{
RESPONSE=`curl ${CURL_OUTPUT_MODE} --insecure --user ${USER}  -X GET ${URL} --header ${CONTENT_TYPE}`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

declare -i AUTHENTICATION_WORKED=`cat ${TEMP_FILE_TWO} | grep -c domainName`

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

if [ $AUTHENTICATION_WORKED -eq 0 ]
then
# Connection Failed

	if [ $CONNECTION_VERBOSITY -eq 0 ]
	then
	return 1
	else

echo ""
echo "Error: Cannot authenticate to GroupWise Administration Service"
echo ""
	fi
# CALL_EXIT 1
else
# Connection Succeeded

	if [ $CONNECTION_VERBOSITY -eq 0 ]
	then
	return 0
	else

echo ""
echo "--------------------------------------------------------------"
echo "Success: Authenticated to the GroupWise Administration Service"
echo "--------------------------------------------------------------"
echo ""
	fi
fi
}


function CHECK_CIMITRA_SERVICE()
{
if [ $SKIP_CONNECTIVITY_CHECKS -eq 1 ]
then
return 0
fi

echo ""
echo "Process: Checking Cimitra Authentication Credentials"

declare -i CONNECTION_VERBOSITY=$1

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"
GW_ADMIN_SERVICE_PORT="443"
GW_ADMIN_USER="admin@cimitra.com"
GW_ADMIN_PASSWORD="changeme"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/users/login" 

URL="${BASEURL}${ENDPOINT}" 

DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}" 

{
RESPONSE=`curl -k -f -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"`
} 2> /dev/null

declare -i STATUS=`echo "${RESPONSE}" | grep -c ',\"homeFolderId\":\"'` 

if [ ${STATUS} -eq 0 ] 
then 
echo "--------------------------------------------------"
echo ""
curl -k ${CURL_OUTPUT_MODE} -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"
echo ""
echo "--------------------------------------------------"
echo "" 
echo "Error: Could Not Establish Connection to Cimitra Server" 
return 1
fi 
echo ""
echo "Success: Established Connection to Cimitra Server"
return 0

}

function CREATE_EXCLUDE_GROUP()
{

cd ${SCRIPT_PATH}

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

source ${GW_SCRIPT_SETTINGS_FILE}

./gw_group_create.sh -o 1  -d ${GW_EXCLUDE_GROUP_DOMAIN_NAME} -p ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} -i ${GW_EXCLUDE_GROUP_NAME}

}

function DISABLE_EXCLUDE_GROUP()
{


if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
echo ""
echo "Exclude Group is Now [DISABLED]"
echo ""
exit 0
}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{

GW_EXCLUDE_GROUP_NAME="exclude_group_name_here"
GW_EXCLUDE_GROUP_POST_OFFICE_NAME="exclude_group_post_office_name_here"
GW_EXCLUDE_GROUP_DOMAIN_NAME="exclude_group_domain_name_here"
declare -i GW_EXCLUDE_GROUP_ENABLED=0
declare -i ENABLED_STATUS=0
declare -i CURRENT_ERROR_STATUS=0

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
ENABLED_STATUS="0"
else
ENABLED_STATUS="1"
fi

source ${GW_SCRIPT_SETTINGS_FILE}

if [ '${GW_EXCLUDE_GROUP_NAME}' == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo "${GROUP_GET_OBJECT}" | grep -ic ":404"`


if [ $ALLOW_GROUP_CREATION -gt 0 ]
then

	if [ ${GROUP_GET_WORKED} -ne 0 ]
	then
	
	echo ""
	echo "NOTE: The Group \"${GW_EXCLUDE_GROUP_NAME}\" Does Not Currently Exist . . ."
	echo ""
	echo "Or it has no members in the Group."
	echo ""
	echo ". . . Cimitra will attempt to create the group right now."
	echo ""
	CREATE_EXCLUDE_GROUP
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""	
	echo "Add Users to the Exclude Group, and Then Enable The Exclude Group"
	echo ""
	return 0
	fi

else
	if [ ${GROUP_GET_WORKED} -ne 0 ]
	then
	echo "Error: Cannot Find Exclude Group or Exclude Group Members For:"
	echo ""
	echo "Group: ${GW_EXCLUDE_GROUP_NAME}"
	echo ""
	echo "Group Post Office: [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} ]"
	echo ""
	echo "Domain For Post Office: ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} : [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} ]"
	echo ""
	echo "Please create the Group in GroupWise Administration"
	echo ""
	echo "And then define the Exclude Group Again in Cimitra Administration"
	echo ""
		if [ $ENABLED_STATUS -eq 1 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
		echo "Exclude Group is Now [DISABLED]"
		echo ""
		fi
		return 1
	fi
fi

declare GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

re='^[0-9]+$'

if ! [[ ${GROUP_GET_OBJECT_COUNTER} =~ $re ]] 
then
echo "NOTE: No users exist in the Exclude Group: ${GW_EXCLUDE_GROUP_NAME}"
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
return 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
	if [ $ENABLED_STATUS -eq 1 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"
	echo "Exclude Group is Now [DISABLED]"
	echo ""
	fi
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

declare -i COUNTER=0

echo ""
echo "Exclude Group Name: ${GW_EXCLUDE_GROUP_NAME}"
echo ""
echo "GroupWise Domain Name For Exclude Group: ${GW_EXCLUDE_GROUP_DOMAIN_NAME}"
echo ""
echo "GroupWise Post Office For Exclude Group: ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}"
echo ""
echo "Exclude Group User Membership for Group: ${GW_EXCLUDE_GROUP_NAME}"
echo ""

while read USER_RECORD
do


if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

let COUNTER=COUNTER+1


echo "GROUP MEMBER: ${USER_RECORD}"
echo ""


done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

if [ $COUNTER -eq 0 ]
then
echo ""
echo "Currently No Users Are Members of The Exclude Group: \"${GW_EXCLUDE_GROUP_NAME}\""
echo ""
else
	if [ $ENABLED_STATUS -eq 0 ]
	then
		if [ $ALLOW_EXCLUDE_GROUP_ENABLEMENT -eq 1 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "1" "${GW_SCRIPT_SETTINGS_FILE}"
		echo "Exclude Group is Now [ENABLED]"
		echo ""	
		fi
	fi

echo "Number of Members in Exclude Group: ${COUNTER}"
echo ""

fi

}

function CONFIGURE_GW_EXCLUSION_GROUP()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

SUGGESTION="CIMITRA_EXCLUDE"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

INPUT="${VAR1}"
# BLISS

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

if [ $INPUT_LENGTH -lt 4 ]
then
	if [ $INPUT_VALID -gt 0 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_NAME" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
	fi
else
	if [ $INPUT_VALID -gt 0 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
	fi
fi


GW_EXCLUDE_GROUP_POST_OFFICE_NAME="PO1"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

INPUT="${VAR2}"

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

if [ $INPUT_LENGTH -lt 4 ]
then
	if [ $INPUT_VALID -gt 0 ]
	then
	echo "Error: Please fill in a correct GroupWise Post Office name"
	CALL_EXIT "1"
	fi
else
	if [ $INPUT_VALID -gt 0 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_POST_OFFICE_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
	fi
fi


GW_EXCLUDE_GROUP_DOMAIN_NAME="domain1"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_EXCLUDE_GROUP_DOMAIN_NAME}"

INPUT="${VAR3}"

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

if [ $INPUT_LENGTH -lt 4 ]
then
	if [ $INPUT_VALID -gt 0 ]
	then
	echo "Error: Please fill in a correct GroupWise Domain name"
	CALL_EXIT "1"
	fi
else
	if [ $INPUT_VALID -gt 0 ]
	then
	TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_DOMAIN_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
	fi
fi


ALLOW_GROUP_CREATION=1
GET_EXCLUDE_GROUP_MEMBERSHIP

}


function PROMPT_FOR_CIMITRA_SETTINGS()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[CIMITRA SERVER INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${CIMITRA_SERVER_ADDRESS}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "Cimitra Server Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


CIMITRA_SERVER_PORT="443"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_PORT}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "Cimitra Server Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${CIMITRA_SERVER_ADMIN_ACCOUNT}"
echo -e "\033[0;93m\033[44m[ADMIN USER ACCOUNT TO ASSIGN GW SCRIPT RIGHTS TO]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

CIMITRA_SERVER_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset thePassword
echo -n "Password:"
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${thePassword%?}"
    else
        prompt='*'
        thePassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_PASSWORD" "${thePassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi




}

function PROMPT_FOR_SETTINGS()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi



LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_ADMIN_SERVICE_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN SERVICE INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${GW_ADMIN_SERVICE_ADDRESS}"
echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN SERVICE ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "GroupWise Admin Service Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_ADMIN_SERVICE_PORT="9710"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_ADMIN_SERVICE_PORT}"
echo -e "\033[0;93m\033[44m[ADMIN SERVICE PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "Admin Service Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



GW_ADMIN_USER="admin"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${GW_ADMIN_USER}"
echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN LEVEL USER]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_USER" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_USER" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

GW_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null


SUGGESTION="${GW_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset thePassword
echo -n "Password:"
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${thePassword%?}"
    else
        prompt='*'
        thePassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_PASSWORD" "${thePassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


CHECK_GWADMIN_SERVICE "0"

declare -i CONNECTION_WORKED=`echo $?`

if [ $CONNECTION_WORKED -eq 0 ]
then

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"
ENDPOINT="system/directories"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

DIRECTORY_EXISTS=`cat "${TEMP_FILE_TWO}" | grep -ic "directoryId"`

fi

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

if [ $DIRECTORY_EXISTS -eq 0 ]
then
return
fi


LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
echo ""
echo -e "\033[0;93m\033[44m[eDIR/LDAP SERVICE INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS}"
echo -e "\033[0;93m\033[44m[eDir/LDAP ADMIN SERVICE ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "eDir/LDAP Server Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT="389"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT}"
echo -e "\033[0;93m\033[44m[ADMIN SERVICE PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "eDir/LDAP Service Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



GW_EDIR_ADMIN_USER="cn=admin,o=cimitra"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${GW_EDIR_ADMIN_USER}"
echo -e "\033[0;93m\033[44m[eDIR/LDAP SERVICE ADMIN LEVEL USER]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_USER" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_USER" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

GW_EDIR_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null


SUGGESTION="${GW_EDIR_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset ldapPassword
echo -n "Password: "
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${ldapPassword%?}"
    else
        prompt='*'
        ldapPassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_PASSWORD" "${ldapPassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo ""
echo "Process: Checking eDir/LDAP Authentication Credentials"
echo ""

RESPONSE=`ldapsearch -D ${GW_EDIR_ADMIN_USER} -w ${GW_EDIR_ADMIN_PASSWORD} -b "${GW_EDIR_ADMIN_USER}"`

declare -i EXIT_CODE=`echo $?`

if [ $EXIT_CODE -eq 0 ]
then
echo ""
echo -e "\033[0;93m\033[0;92m"
echo "-----------------------------------------------"
echo "Success: Authenticated to the eDir/LDAP Service"
echo "-----------------------------------------------"
else
echo ""
echo ""
echo "Error: Cannot authenticate to eDir/LDAP Service"
fi

}


### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

echo "GW_ADMIN_SERVICE_ADDRESS=\"${LOCAL_IP}\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
echo ""
# CALL_EXIT 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
echo ""
# CALL_EXIT 1
fi

# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function GET_EXCLUDE_GROUP_INFO()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
echo ""
echo "Currently the Exclude Group is [DISABLED]"
else
echo ""
echo "Currently the Exclude Group is [ENABLED]"
fi

ALLOW_EXCLUDE_GROUP_ENABLEMENT="0"
GET_EXCLUDE_GROUP_MEMBERSHIP
}



function TEST()
{
echo "${FUNCNAME}"
}



main()
{
$FUNCTION_IN
}


main

CALL_EXIT 0


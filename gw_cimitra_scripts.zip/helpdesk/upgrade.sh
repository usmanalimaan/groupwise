#!/bin/bash
###########################################
# integrate.sh                            #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 3/3/2020                   #
###########################################
# Cimitra/GroupWise Integration Upgrade script
declare CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
declare CIMITRA_SERVER_ADMIN_PASSWORD="changeme"
declare CIMITRA_SERVER_ADDRESS="bogus_address.example.com"
declare CIMITRA_SERVER_PORT="443"
TEMP_FILE_DIRECTORY="/var/tmp"
GW_SCRIPT_SETTINGS_FILE=""
declare DISCOVERY_SCRIPT_FILE="gw_po_list_titles.sh"

declare -i SKIP_GWSCRIPT_UPGRADE=0
declare -i SHOW_HELP_SCREEN=0
declare -i CIMITRA_API_SESSION_ESTABLISHED=0
declare SCRIPT_PATH="/var/opt/cimitra/scripts/groupwise-master/helpdesk"

BASE_GW_SCRIPT_DIR="/var/opt/cimitra/scripts/groupwise-master/helpdesk"

while getopts "hs" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN="1"
      ;;
    s) SKIP_GWSCRIPT_UPGRADE="1"
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

function SHOW_HELP()
{

echo "--- Script Help ---"
echo ""
echo "Cimitra/GroupWise Integration Upgrade Script Help"

declare -i IN_BASE_DIR=`pwd | grep -c "${BASE_GW_SCRIPT_DIR}"`

if [ $IN_BASE_DIR -eq 1 ]
then
echo ""
echo "$0 | Upgrades The GroupWise Integration Scripts in ${BASE_GW_SCRIPT_DIR}"
else
CURRENT_DIR=`pwd`
echo ""
echo "$0 | Upgrades The Main GroupWise Integration Scripts in ${BASE_GW_SCRIPT_DIR} and then . . ."
echo ""
echo ". . . the Scripts are Then Copied to This Directory: ${CURRENT_DIR}"
echo ""
echo "Optional Feature: $0 -s | Skip Upgrading The Main GroupWise Integration Scripts"
fi
echo ""
echo "Help: $0 -h"
echo ""
}

function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
return
fi

source ${GW_SCRIPT_SETTINGS_FILE}

}

function UPGRADE()
{
if [ $SKIP_GWSCRIPT_UPGRADE -eq 0 ]
then
cimitra get gw
cimitra gw update
fi

declare -i IN_BASE_DIR=`pwd | grep -c "${BASE_GW_SCRIPT_DIR}"`

if [ $IN_BASE_DIR -eq 1 ]
then
return 0 
fi

cp ${BASE_GW_SCRIPT_DIR}/*.sh ./

}

function UPGRADE_ADDITIONAL_DIRECTORIES()
{

cd ${BASE_GW_SCRIPT_DIR}

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
return 1
fi

declare -i SUB_DIR_EXISTS=`ls -1d */ | wc -l`

if [ $SUB_DIR_EXISTS -eq 0 ]
then
return 0
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

ls -1d */ | sed 's|/||g' > $TEMP_FILE_ONE

while read CURRENT_LINE
do

cp ${BASE_GW_SCRIPT_DIR}/*.sh ${BASE_GW_SCRIPT_DIR}/${CURRENT_LINE}

cd ${BASE_GW_SCRIPT_DIR}/$CURRENT_LINE

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
continue
fi

echo ""
echo "Updating Code for Post Office $CURRENT_LINE"
echo ""

GW_SCRIPT_SETTINGS_FILE="./settings_gw.cfg"

declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`


if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -eq 0 ]
then

echo ""
echo "Running Integration For Post Office $CURRENT_LINE"
echo ""
./integrate.sh -p $CURRENT_LINE 
fi

cd ${BASE_GW_SCRIPT_DIR}

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
return 1
fi

done < ${TEMP_FILE_ONE}

rm $TEMP_FILE_ONE

}

function ESTABLISH_CIMITRA_API_SESSION()
{

source ${GW_SCRIPT_SETTINGS_FILE}

declare -i SERVER_ADDRESS_NOT_CONFIGURED=`echo "${CIMITRA_SERVER_ADDRESS}" | grep -c "bogus_address.example.com"`

if [ $SERVER_ADDRESS_NOT_CONFIGURED -eq 1 ]
then
return 1
fi

echo ""
echo "Process: Establishing Connection to Cimitra Server"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/users/login" 

URL="${BASEURL}${ENDPOINT}" 


DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}" 

{
RESPONSE=`curl -k -f -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"`
} 2> /dev/null

declare -i STATUS=`echo "${RESPONSE}" | grep -c ',\"homeFolderId\":\"'` 

if [ ${STATUS} -eq 0 ] 
then 
echo "--------------------------------------------------"
echo ""
curl -k ${CURL_OUTPUT_MODE} -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"
echo ""
echo "--------------------------------------------------"
echo "" 
echo "Error: Could Not Establish Connection to Cimitra Server" 
echo ""
return 1
fi 

CIMITRA_API_SESSION_ESTABLISHED="1"

CIMITRA_API_SESSION_TOKEN=`echo "${RESPONSE}" | awk -F \"token\":\" '{printf $2}' | awk -F \" '{printf $1}'`

echo ""
echo "Success: Established Connection to Cimitra Server"
}


function GET_URL()
{
IO_FILE="$1"

if [ $CIMITRA_API_SESSION_ESTABLISHED -eq 0 ]
then
return 1
fi

# Read values from IO File

source ${IO_FILE}

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X GET ${URL}`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${IO_FILE}

return 0
}

function CONFIRM_GW_PO()
{

POST_OFFICE_IN="$1"
POST_OFFICE_IN=`echo "${POST_OFFICE_IN}" | xargs echo -n`

TEMP_FILE_ONE_ONE="${TEMP_FILE_DIRECTORY}/$$.11.tmp"

TEMP_FILE_TWO_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"

{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}` 1> /dev/null 2> /dev/null
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" 1> ${TEMP_FILE_ONE_ONE} 

cat ${TEMP_FILE_ONE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO_TWO}

DOMAIN_IN=`grep "id:USER." ${TEMP_FILE_TWO_TWO} | grep -i ".${POST_OFFICE_IN}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

DOMAIN_IN=`echo "${DOMAIN_IN}" | tr [A-Z] [a-z]`

rm ${TEMP_FILE_ONE_ONE}

rm ${TEMP_FILE_TWO_TWO}

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/domains/${DOMAIN_IN}/postoffices/${POST_OFFICE_IN}"

{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}` 1> /dev/null 2> /dev/null
} 1> /dev/null 2> /dev/null

declare -i POST_OFFICE_EXISTS=`echo "${RESPONSE}" | grep -ic "/gwadmin-service/domains/${DOMAIN_IN}/postoffices/${POST_OFFICE_IN}/clientoptions"`

if [ $POST_OFFICE_EXISTS -gt 0 ]
then
return 1
else
return 0
fi

}


function DISCOVER_INTEGRATED_POST_OFFICES()
{

DISCOVERY_SCRIPT="${SCRIPT_PATH}/${DISCOVERY_SCRIPT_FILE}"

PROCESS_SETTINGS_FILES

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

ESTABLISH_CIMITRA_API_SESSION

ENDPOINT="/apps" 

echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}

GET_URL "${TEMP_FILE_ONE}"

cat ${TEMP_FILE_ONE} | grep -A 1 "${DISCOVERY_SCRIPT}" | grep "params:" | grep "\-p" | tr [A-Z] [a-z] | sort | uniq 1> ${TEMP_FILE_TWO}

rm ${TEMP_FILE_ONE} 2> /dev/null 

declare -i LIST_HAS_CONTENT=`cat ${TEMP_FILE_TWO} | wc -m`

if [ $LIST_HAS_CONTENT -lt 2 ]
then
rm ${TEMP_FILE_TWO} 2> /dev/null
return 0
fi 

while read CURRENT_LINE
do

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F "-p" '{printf $2}'`

echo "POST_OFFICE = $POST_OFFICE"

declare -i POST_OFFICE_HAS_CONTENT=`echo "${POST_OFFICE}" | wc -m`

if [ $POST_OFFICE_HAS_CONTENT -lt 2 ]
then
continue
fi

CONFIRM_GW_PO "${POST_OFFICE}"

declare -i PROCESS_PO=`echo $?`

if [ $PROCESS_PO -eq 1 ]
then
echo ""
echo "Integrating GroupWise Post Office: ${POST_OFFICE}"
echo ""
cd ${SCRIPT_PATH}
./integrate.sh -p ${POST_OFFICE}
else
echo ""
echo "GroupWise Post Office: ${POST_OFFICE} Does Not Exist"
echo ""
fi

done < ${TEMP_FILE_TWO}

rm ${TEMP_FILE_TWO} 2> /dev/null

}

if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

UPGRADE

UPGRADE_ADDITIONAL_DIRECTORIES

DISCOVER_INTEGRATED_POST_OFFICES


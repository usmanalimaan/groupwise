#!/bin/bash
###########################################
# integrate.sh                            #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 3/3/2020                   #
###########################################
# Cimitra/GroupWise Integration Upgrade script

declare -i SKIP_GWSCRIPT_UPGRADE=0
declare -i SHOW_HELP_SCREEN=0

TEMP_FILE_DIRECTORY="/var/tmp"
BASE_GW_SCRIPT_DIR="/var/opt/cimitra/scripts/groupwise-master/helpdesk"

while getopts "hs" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN="1"
      ;;
    s) SKIP_GWSCRIPT_UPGRADE="1"
      ;;
  esac
done

function SHOW_HELP()
{

echo "--- Script Help ---"
echo ""
echo "Cimitra/GroupWise Integration Upgrade Script Help"

declare -i IN_BASE_DIR=`pwd | grep -c "${BASE_GW_SCRIPT_DIR}"`

if [ $IN_BASE_DIR -eq 1 ]
then
echo ""
echo "$0 | Upgrades The GroupWise Integration Scripts in ${BASE_GW_SCRIPT_DIR}"
else
CURRENT_DIR=`pwd`
echo ""
echo "$0 | Upgrades The Main GroupWise Integration Scripts in ${BASE_GW_SCRIPT_DIR} and then . . ."
echo ""
echo ". . . the Scripts are Then Copied to This Directory: ${CURRENT_DIR}"
echo ""
echo "Optional Feature: $0 -s | Skip Upgrading The Main GroupWise Integration Scripts"
fi
echo ""
echo "Help: $0 -h"
echo ""
}

function UPGRADE()
{
if [ $SKIP_GWSCRIPT_UPGRADE -eq 0 ]
then
cimitra get gw
cimitra gw update
fi

declare -i IN_BASE_DIR=`pwd | grep -c "${BASE_GW_SCRIPT_DIR}"`

if [ $IN_BASE_DIR -eq 1 ]
then
return 0 
fi

cp ${BASE_GW_SCRIPT_DIR}/*.sh ./

}

function UPGRADE_ADDITIONAL_DIRECTORIES()
{

cd ${BASE_GW_SCRIPT_DIR}

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
return 1
fi

declare -i SUB_DIR_EXISTS=`ls -1d */ | wc -l`

if [ $SUB_DIR_EXISTS -eq 0 ]
then
return 0
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

ls -1d */ | sed 's|/||g' > $TEMP_FILE_ONE

while read CURRENT_LINE
do

cp ${BASE_GW_SCRIPT_DIR}/*.sh ${BASE_GW_SCRIPT_DIR}/${CURRENT_LINE}

cd ${BASE_GW_SCRIPT_DIR}/$CURRENT_LINE

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
continue
fi

echo ""
echo "Updating Code for Post Office $CURRENT_LINE"
echo ""

GW_SCRIPT_SETTINGS_FILE="./settings_gw.cfg"

declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`


if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -eq 0 ]
then

echo ""
echo "Running Integration For Post Office $CURRENT_LINE"
echo ""
./integrate -p $CURRENT_LINE 
fi

cd ${BASE_GW_SCRIPT_DIR}

declare -i CHANGE_DIR_WORKED=`echo $?`

if [ $CHANGE_DIR_WORKED -ne 0 ]
then
return 1
fi

done < ${TEMP_FILE_ONE}

rm $TEMP_FILE_ONE

}

if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

UPGRADE

UPGRADE_ADDITIONAL_DIRECTORIES


#!/bin/bash
###########################################
# setup.sh                                #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 3/3/2020                   #
###########################################
# Cimitra/GroupWise Integration Setup script

declare -i SHOW_HELP_SCREEN=0
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"
declare -i CONFIGURE_SETTINGS=0
declare -i TEST_CONNECTIVITY=0
declare -i MENU_MODE=1
declare -i FAILED_SETUP=0
declare -i RECONFIGURE=0
declare -i DIRECTORY_EXISTS=0
declare -i SKIP_CONNECTIVITY_CHECKS=0
declare -i DEBUG_MODE=0

declare -i GROUP_IN_SET=0
declare -i POST_OFFICE_IN_SET=0

while getopts "chmtvsz" opt; do
  case ${opt} in
    c) CONFIGURE_SETTINGS="0"
      ;;
    h) SHOW_HELP_SCREEN=1
      ;;
    m) MENU_MODE="0"
      ;;
    t) TEST_CONNECTIVITY="1"
      ;;
    s) SKIP_CONNECTIVITY_CHECKS="1"
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
    z) DEBUG_MODE=1
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Setup Script"
echo ""
echo "Script usage:      $0 [options]"
echo ""
echo "Example:           $0"
echo ""
echo "Configure Mode:    $0 -c or $0 configure"
echo ""
echo "Test Connectivity: $0 -t or $0 test"
echo ""
echo "Skip Connectivity Testing: $0 -s"
echo ""
echo "Verbose Mode:      $0 -v"
echo ""
echo "Debug Mode:        $0 -z"
echo ""
echo "Help:              $0 -h or $0 -h "
echo ""
}

function CALL_EXIT()
{
EXIT_CODE=$1
echo -e "\e[0m"
echo "Goodbye"
echo ""
echo "To run this script again do this:" 
echo ""
echo "Go to this path: ${SCRIPT_PATH}"
echo ""
echo "Run: $0"
echo ""
exit ${EXIT_CODE}
}

declare -i FIRST_INPUT_IS_HELP=`echo "$1" | grep -ic "help"`

if [ $FIRST_INPUT_IS_HELP -gt 0 ]
then
SHOW_HELP
exit 0
fi

declare -i FIRST_INPUT_IS_MENU=`echo "$1" | grep -ic "menu"`

if [ $FIRST_INPUT_IS_MENU -gt 0 ]
then
GET_CONFIGURATION_INFO="1"
fi

declare -i FIRST_INPUT_IS_CONFIGURE=`echo "$1" | grep -ic "configure"`

if [ $FIRST_INPUT_IS_CONFIGURE -gt 0 ]
then
GET_CONFIGURATION_INFO="1"
fi

declare -i FIRST_INPUT_IS_TEST=`echo "$1" | grep -ic "test"`

if [ $FIRST_INPUT_IS_TEST -gt 0 ]
then
TEST_CONNECTIVITY="1"
fi

function TEXT_EDITOR_REPLACE()
{
# TEXT_EDITOR_REPLACE "SETTING_NAME" "${SETTING_VARIABLE}" "$CONFIG_FILE"

declare -i ARG_ONE_EMPTY=`echo "$1" | wc -c`
declare -i ARG_TWO_EMPTY=`echo "$2" | wc -c`
declare -i ARG_THREE_EMPTY=`echo "$3" | wc -c`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

if [ $ARG_ONE_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_TWO_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_THREE_EMPTY -lt 2 ]
then
return
else
:
fi

touch $3
declare -i LINES_PRIOR_TO_REMOVAL=`grep -c "=" $3`
declare -i EQUALS_EXIST=`grep -c "=" $3`

egrep -v "${1}=" $3 | sed '/^[[:space:]]*$/d' > ${TEMP_FILE_ONE}


declare -i LINES_AFTER_REMOVAL=`grep -c "=" ${TEMP_FILE_ONE}`
declare -i DIFFERENCE_OF_LINES_REMOVED=0
let DIFFERENCE_OF_LINES_REMOVED=LINES_PRIOR_TO_REMOVAL-LINES_AFTER_REMOVAL

if [ $DIFFERENCE_OF_LINES_REMOVED -gt 3 ]
then
rm ${TEMP_FILE_ONE}
echo ""
date
echo "It seems something is wrong, this setting change will not be made"
echo ""
fi


rm $3
mv ${TEMP_FILE_ONE} $3 
echo "${1}=\"${2}\"" >> $3

} # 2> /dev/null

function TEXT_EDITOR_CONFIRM()
{

declare -i ARG_ONE_EMPTY=`echo "$1" | wc -c`
declare -i ARG_TWO_EMPTY=`echo "$2" | wc -c`
declare -i ARG_THREE_EMPTY=`echo "$3" | wc -c`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

if [ $ARG_ONE_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_TWO_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_THREE_EMPTY -lt 2 ]
then
return
else
:
fi

touch $3

declare -i LINE_EXISTS=`grep -wc "$2" $3`


if [ $LINE_EXISTS -gt 0 ]
then
return 0
fi

TEXT_EDITOR_REPLACE "$1" "$2" "$3"

}

function CHECK_GWADMIN_SERVICE()
{
if [ $SKIP_CONNECTIVITY_CHECKS -eq 1 ]
then
return 0
fi

echo ""
echo "Process: Checking GroupWise Authentication Credentials"

declare -i CONNECTION_VERBOSITY=$1

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_ADMIN_SERVICE_ADDRESS="${LOCAL_IP}"
GW_ADMIN_SERVICE_PORT="9710"
GW_ADMIN_USER="admin"
GW_ADMIN_PASSWORD="LetMeInOk"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

URL="${BASEURL}/${ENDPOINT}"

USER="${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD}"

CONTENT_TYPE='"Content-Type: application/json"'

{
RESPONSE=`curl ${CURL_OUTPUT_MODE} --insecure --user ${USER}  -X GET ${URL} --header ${CONTENT_TYPE}`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

declare -i AUTHENTICATION_WORKED=`cat ${TEMP_FILE_TWO} | grep -c domainName`

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

if [ $AUTHENTICATION_WORKED -eq 0 ]
then
# Connection Failed

	if [ $CONNECTION_VERBOSITY -eq 0 ]
	then
	return 1
	else

echo ""
echo "Error: Cannot authenticate to GroupWise Administration Service"
echo ""
	fi
# CALL_EXIT 1
else
# Connection Succeeded

	if [ $CONNECTION_VERBOSITY -eq 0 ]
	then
	return 0
	else

echo ""
echo -e "\033[0;93m\033[0;92m"
echo "--------------------------------------------------------------"
echo "Success: Authenticated to the GroupWise Administration Service"
echo "--------------------------------------------------------------"
echo ""
	fi
fi
}


function CHECK_CIMITRA_SERVICE()
{
if [ $SKIP_CONNECTIVITY_CHECKS -eq 1 ]
then
return 0
fi

echo ""
echo "Process: Checking Cimitra Authentication Credentials"

declare -i CONNECTION_VERBOSITY=$1

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"
GW_ADMIN_SERVICE_PORT="443"
GW_ADMIN_USER="admin@cimitra.com"
GW_ADMIN_PASSWORD="changeme"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/users/login" 

URL="${BASEURL}${ENDPOINT}" 

DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}" 

{
RESPONSE=`curl -k -f -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"`
} 2> /dev/null

declare -i STATUS=`echo "${RESPONSE}" | grep -c ',\"homeFolderId\":\"'` 

if [ ${STATUS} -eq 0 ] 
then 
echo "--------------------------------------------------"
echo ""
curl -k ${CURL_OUTPUT_MODE} -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"
echo ""
echo "--------------------------------------------------"
echo "" 
echo "Error: Could Not Establish Connection to Cimitra Server" 
return 1
fi 
echo ""
echo "Success: Established Connection to Cimitra Server"
return 0

}

function PROMPT_FOR_GW_EXCLUSION_GROUP()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

GW_EXCLUDE_GROUP_NAME="GW_EXCLUDE_GROUP"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[EXCLUSION GROUP NAME]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${GW_EXCLUDE_GROUP_NAME}"
echo -e "\033[0;93m\033[44m[GROUPWISE GROUP WITH USERS TO EXCLUDE]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit group>\033[0;93m\033[0;92m"
read -p "GroupWise Exclude: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_NAME" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_EXCLUDE_GROUP_POST_OFFICE_NAME="PO1"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}"
echo -e "\033[0;93m\033[44m[POST OFFICE THAT OWNS THE GROUP: ${GW_EXCLUDE_GROUP_NAME} ]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit Post Office Name>\033[0;93m\033[0;92m"
read -p "Post Office: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_POST_OFFICE_NAME" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_POST_OFFICE_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_EXCLUDE_GROUP_DOMAIN_NAME="domain1"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_EXCLUDE_GROUP_DOMAIN_NAME}"

echo -e "\033[0;93m\033[44m[DOMAIN THAT OWNS THE POST OFFICE: ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} ]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit Domain Name>\033[0;93m\033[0;92m"
read -p "Domain: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_DOMAIN_NAME" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_DOMAIN_NAME" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

TEXT_EDITOR_REPLACE "GW_EXCLUDE_GROUP_ENABLED" "0" "${GW_SCRIPT_SETTINGS_FILE}"

./call_configure_exclude_group_enable.sh

}



function PROMPT_FOR_CIMITRA_SETTINGS()
{
# BLISS
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[CIMITRA SERVER INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${CIMITRA_SERVER_ADDRESS}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "Cimitra Server Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


CIMITRA_SERVER_PORT="443"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_PORT}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "Cimitra Server Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${CIMITRA_SERVER_ADMIN_ACCOUNT}"
echo -e "\033[0;93m\033[44m[ADMIN USER ACCOUNT TO ASSIGN GW SCRIPT RIGHTS TO]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

CIMITRA_SERVER_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset thePassword
echo -n "Password:"
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${thePassword%?}"
    else
        prompt='*'
        thePassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_PASSWORD" "${thePassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi




}

function PROMPT_FOR_SETTINGS()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi



LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_ADMIN_SERVICE_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN SERVICE INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${GW_ADMIN_SERVICE_ADDRESS}"
echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN SERVICE ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "GroupWise Admin Service Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_ADMIN_SERVICE_PORT="9710"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_ADMIN_SERVICE_PORT}"
echo -e "\033[0;93m\033[44m[ADMIN SERVICE PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "Admin Service Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_SERVICE_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



GW_ADMIN_USER="admin"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${GW_ADMIN_USER}"
echo -e "\033[0;93m\033[44m[GROUPWISE ADMIN LEVEL USER]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_USER" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_USER" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

GW_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null


SUGGESTION="${GW_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset thePassword
echo -n "Password:"
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${thePassword%?}"
    else
        prompt='*'
        thePassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_ADMIN_PASSWORD" "${thePassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


CHECK_GWADMIN_SERVICE "0"

declare -i CONNECTION_WORKED=`echo $?`

if [ $CONNECTION_WORKED -eq 0 ]
then

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"
ENDPOINT="system/directories"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

DIRECTORY_EXISTS=`cat "${TEMP_FILE_TWO}" | grep -ic "directoryId"`

fi

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

if [ $DIRECTORY_EXISTS -eq 0 ]
then
return
fi


LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS="${LOCAL_IP}"

source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
echo ""
echo -e "\033[0;93m\033[44m[eDIR/LDAP SERVICE INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"


SUGGESTION="${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS}"
echo -e "\033[0;93m\033[44m[eDir/LDAP ADMIN SERVICE ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "eDir/LDAP Server Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT="389"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT}"
echo -e "\033[0;93m\033[44m[ADMIN SERVICE PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "eDir/LDAP Service Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi



GW_EDIR_ADMIN_USER="cn=admin,o=cimitra"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${GW_EDIR_ADMIN_USER}"
echo -e "\033[0;93m\033[44m[eDIR/LDAP SERVICE ADMIN LEVEL USER]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_USER" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_USER" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

GW_EDIR_ADMIN_PASSWORD=""
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null


SUGGESTION="${GW_EDIR_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT
unset ldapPassword
echo -n "Password: "
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${ldapPassword%?}"
    else
        prompt='*'
        ldapPassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "GW_EDIR_ADMIN_PASSWORD" "${ldapPassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo ""
echo "Process: Checking eDir/LDAP Authentication Credentials"
echo ""

RESPONSE=`ldapsearch -D ${GW_EDIR_ADMIN_USER} -w ${GW_EDIR_ADMIN_PASSWORD} -b "${GW_EDIR_ADMIN_USER}"`

declare -i EXIT_CODE=`echo $?`

if [ $EXIT_CODE -eq 0 ]
then
echo ""
echo -e "\033[0;93m\033[0;92m"
echo "-----------------------------------------------"
echo "Success: Authenticated to the eDir/LDAP Service"
echo "-----------------------------------------------"
else
echo ""
echo ""
echo "Error: Cannot authenticate to eDir/LDAP Service"
fi

}


### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

LOCAL_IP=`ip address show eth0 | grep inet | head -1 | awk '{printf $2}' | awk -F "/" '{printf $1}'`

echo "GW_ADMIN_SERVICE_ADDRESS=\"${LOCAL_IP}\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
echo ""
# CALL_EXIT 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
echo ""
# CALL_EXIT 1
fi

# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function INTEGRATION_MENU()
{
echo ""
# Make red menu
echo -e "\e[41mCtrl-C To Quit This Action!\033[0;93m\033[0;92m"
# Make friendly bright green menu
echo -e "\033[0;93m\033[0;92m"
echo "--------------------------------------------------"
echo "| Cimitra GroupWise Integration Post Office Menu |"
echo "--------------------------------------------------"
echo ""
echo -n "Enter Post Office Name: "
read CHOICE
echo ""
echo "Process: Integrate"
echo ""
echo "Running the Cimitra/GroupWise Integration Script"
echo ""
if [ $DEBUG_MODE -eq 0 ]
then
echo "${SCRIPT_PATH}/integrate.sh -p ${CHOICE}"
echo ""
${SCRIPT_PATH}/integrate.sh -p ${CHOICE}
else
echo "${SCRIPT_PATH}/integrate.sh -z -p ${CHOICE}"
echo ""
${SCRIPT_PATH}/integrate.sh -z -p ${CHOICE}
fi

}


function INTEGRATION_REVERSE_MENU()
{
# Make red menu
echo -e "\e[41mCtrl-C To Quit This Action!\033[0;93m\033[0;92m"
# Make friendly bright green menu
echo -e "\033[0;93m\033[0;92m"
echo "----------------------------------------------------------"
echo "| Cimitra Reverse GroupWise Integration Post Office Menu |"
echo "----------------------------------------------------------"
echo ""
echo -n "Enter Post Office Name: "
read CHOICE
echo ""
echo "Process: Reverse Integration"
echo ""
echo "Running the Cimitra/GroupWise Integration Script"
echo ""
echo "${SCRIPT_PATH}/integrate.sh -u -p ${CHOICE}"
echo ""

${SCRIPT_PATH}/integrate.sh -u -p ${CHOICE}

# CALL_EXIT 0
}


function SETUP_MENU()
{
# Configure the settings files
PROCESS_SETTINGS_FILES

# Make friendly bright green menu

echo -e "\033[0;93m\033[0;92m"
echo "Running Menu...(may take a moment)"
echo ""

# See if connectivity works
CHECK_GWADMIN_SERVICE "0"
declare -i GWADMIN_CONNECTIVITY_ESTABLISHED=`echo $?`

# If connectivity doesn't work, return and configure connectivity
if [ $GWADMIN_CONNECTIVITY_ESTABLISHED -eq 1 ]
then
FAILED_SETUP=1
CONFIGURE_SETTINGS=1
return
fi

FAILED_SETUP=0

CHOICE="0"

declare -i ERROR_COUNTER=0
declare -i ERROR_MAX=5

function UPGRADE_CODE()
{
./upgrade.sh
}

function MENU_PROMPT()
{
echo "-------------------------------------------"
echo "| Cimitra GroupWise Integration Main Menu |"
echo "-------------------------------------------"
echo ""
echo "[1] Initiate Cimitra/GroupWise Integration"
echo ""
echo "[2] Configure GroupWise Admin Credentials"
echo ""
echo "[3] Configure Cimitra/GroupWise Integration Admin User"
echo ""
echo "[4] Add Post Office Integration"
echo ""
echo "[5] Define GroupWise Exclusion Group"
echo ""
echo "[6] Remove Post Office Integration"
echo ""
echo "[7] Upgrade Cimitra/GroupWise Integration Module"
echo ""
echo "[8] Exit"
echo ""
echo -n "Enter Menu Choice 1,2,3,4,5,6,7 or 8: "
 
read CHOICE

echo -e "\033[0;93m\033[0;92m"
}


until [ $CHOICE -eq 1 ] 2> /dev/null || [ $CHOICE -eq 2 ] 2> /dev/null || [ $CHOICE -eq 3 ] 2> /dev/null || [ $CHOICE -eq 4 ] 2> /dev/null || [ $CHOICE -eq 5 ] 2> /dev/null || [ $CHOICE -eq 6 ] 2> /dev/null || [ $CHOICE -eq 7 ] 2> /dev/null || [ $CHOICE -eq 8 ] 2> /dev/null

do 

let ERROR_COUNTER=ERROR_COUNTER+1

MENU_PROMPT

if [ $ERROR_COUNTER -gt $ERROR_MAX ]
then
echo ""
echo "That was fun!"
CALL_EXIT 1
fi
done

case $CHOICE in
1)
${SCRIPT_PATH}/integrate.sh -e
SETUP_MENU
;;
2)
ERROR_COUNTER=0
echo ""
echo "Process: Configure GroupWise Admin Credentials"
echo ""
PROCESS_SETTINGS_FILES
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
SETUP_MENU
;;
3)
ERROR_COUNTER=0
echo ""
echo "Process: Configure Cimitra/GroupWise Integration Admin User"
echo ""
PROCESS_SETTINGS_FILES
PROMPT_FOR_CIMITRA_SETTINGS
CHECK_CIMITRA_SERVICE "1"
SETUP_MENU
;;
4)
ERROR_COUNTER=0
RECONFIGURE=1
CONFIGURE_SETTINGS=0
INTEGRATION_MENU
SETUP_MENU
;;
5)
ERROR_COUNTER=0
echo ""
echo "Process: Define GroupWise Exclusion Group"
echo ""
PROCESS_SETTINGS_FILES
PROMPT_FOR_GW_EXCLUSION_GROUP
SETUP_MENU
;;
6)
ERROR_COUNTER=0
INTEGRATION_REVERSE_MENU
SETUP_MENU
;;
7)
echo ""
echo "Process: Upgrade Cimitra/GroupWise Integration Module"
echo ""
UPGRADE_CODE
SETUP_MENU
;;
8)
CALL_EXIT 0
;;
esac
}

function CREATE_OR_CONFIRM_SETTINGS()
{
TEXT_EDITOR_CONFIRM "USER_ACCESS_FOLDER_LABEL" "USER ACCESS" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "USER_CHANGES_FOLDER_LABEL" "USER CHANGES" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "USER_FIXES_FOLDER_LABEL" "USER FIXES" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "USER_REPORTS_FOLDER_LABEL" "USER REPORTS" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "CREATE_FOLDER_LABEL" "CREATE" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "DELETE_FOLDER_LABEL" "REMOVE/DELETE/CHANGE" "${GW_SCRIPT_SETTINGS_FILE}"
TEXT_EDITOR_CONFIRM "LDAP_EMPTY_FIELD_CHARACTER" "-" "${GW_SCRIPT_SETTINGS_FILE}"
}

function main()
{

PROCESS_SETTINGS_FILES
CREATE_OR_CONFIRM_SETTINGS


if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
CALL_EXIT 0
fi

if [ $MENU_MODE -eq 1 ]
then
SETUP_MENU
fi

if [ $TEST_CONNECTIVITY -eq 1 ]
then
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE "1"
CALL_EXIT 0
fi

if [ $CONFIGURE_SETTINGS -eq 1 ]
then
PROCESS_SETTINGS_FILES
PROMPT_FOR_SETTINGS
CHECK_GWADMIN_SERVICE "1"
fi

if [ $FAILED_SETUP -eq 1 ]
then
echo "Failed Setup"
FAILED_SETUP=0
SETUP_MENU
fi
# SETUP_CREDENTIALS_COUNTER
}

main

CALL_EXIT 0


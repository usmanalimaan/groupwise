#!/bin/bash
###########################################
# integrate.sh                            #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 3/3/2020                   #
###########################################
# Cimitra/GroupWise Integration Integration script

LOCAL_IP=`ifconfig eth0 | grep "inet addr" | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1`

declare CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"
declare CIMITRA_SERVER_PORT="443"
declare CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
declare CIMITRA_SERVER_ADMIN_PASSWORD="changeme"
declare -i CIMITRA_SERVER_CREDENTIALS_REQUIRED=0
declare -i CIMITRA_SERVER_ADDRESS_AND_PORT_REQUIRED=0
GW_SCRIPT_SETTINGS_FILE=""
declare -i RUN_CONNECTION_TEST=0
declare -i CIMITRA_API_CONNECTION_ESTABLISHED=0
declare -i GROUPWISE_API_CONNECTION_ESTABLISHED=0
declare CIMITRA_API_SESSION_TOKEN=""
declare CIMITRA_PAIRED_AGENT_ID=""
declare CIMITRA_GROUPWISE_ROOT_FOLDER_ID=""
declare CIMITRA_ROOT_FOLDER_ID=""
declare CIMITRA_GROUPWISE_HELPDESK_FOLDER_ID=""
declare GROUPWISE_ADMIN_FOLDER_ID=""
declare HELPDESK_GROUPWISE_PO_FOLDER_ID=""
declare -i HELPDESK_GROUPWISE_PO_FOLDER_ID_OBTAINED=0
declare CIMITRA_GROUPWISE_ROOT_FOLDER_NAME=""
declare USER_ACCESS_FOLDER_ID=""
declare USER_CHANGES_FOLDER_ID=""
declare USER_FIXES_FOLDER_ID=""
declare USER_REPORTS_FOLDER_ID=""
declare CREATE_FOLDER_ID=""
declare -i CREATE_APP_ADDITIONAL_INPUT_ON=0
declare CREATE_APP_ADDITIONAL_INPUT_VALUE=""
declare CREATE_ONLY_USER_AND_ONE_INPUT_APP_ADDITIONAL_PARAMETER_VALUE=""
declare ADDITIONAL_APP_PARAMETER=""
declare -i INSTALL_CIMITRA_AGENT=1
declare -i FUNCTION_RUN=0
declare -i GET_CONFIGURATION_INFO=0
declare -i SHOW_HELP_SCREEN=0

declare -i CREATE_SUB_FOLDER_STRUCTURE=1
GW_SCRIPT_SETTINGS_FILE=""

declare -i POST_OFFICE_IN_SET=0
declare -i DOMAIN_IN_SET=0
declare -i CIMITRA_AGENT_IN_SET=0
declare -i ALL_SET=0
declare -i FOLDER_ID_IN_SET=0
declare -i CREATE_SYSTEM_APPS=1
declare -i UNINSTALL_CIMITRA_APP_STRUCTURE=0
declare CURRENT_WORKING_DIRECTORY=`pwd`

declare CURL_OUTPUT_MODE="--silent"

while getopts "a:f:p:chimtvsu" opt; do
  case ${opt} in
    a) CIMITRA_AGENT_IN="$OPTARG"
	CIMITRA_AGENT_IN_SET=1
	CIMITRA_AGENT_IN_UPPER=`echo "${CIMITRA_AGENT_IN}" | tr [a-z] [A-Z]`
	CIMITRA_AGENT_IN_LOWER=`echo "${CIMITRA_AGENT_IN}" | tr [A-Z] [a-z]`
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
	POST_OFFICE_IN_UPPER=`echo "${POST_OFFICE_IN}" | tr [a-z] [A-Z]`
	POST_OFFICE_IN_LOWER=`echo "${POST_OFFICE_IN}" | tr [A-Z] [a-z]` 
      ;;
    f) FOLDER_ID_IN="$OPTARG"
	FOLDER_ID_IN_SET=1
      ;;
    c) CREATE_SUB_FOLDER_STRUCTURE=0
	;;
    i) INSTALL_CIMITRA_AGENT=0
	;;
    m) GET_CONFIGURATION_INFO=1
	;;
    s) CREATE_SYSTEM_APPS=0
      ;;
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
      ;;
    t) RUN_CONNECTION_TEST=1
      ;;
    u) UNINSTALL_CIMITRA_APP_STRUCTURE=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "[Cimitra Server Configuration Menu]"
echo ""
echo "$0 -m or $0 menu"
echo ""
echo "[Cimitra Server Connectivity Test]"
echo ""
echo "$0 -t or $0 test"
echo ""
echo "[Cimitra GroupWise Helpdesk Post Office Import/INSTALL]"
echo ""
echo "Script usage:        $0 [options]"
echo ""
echo "Required Syntax:     $0 -p <GroupWise post office>"
echo ""
echo "Example:             $0 -p po1"
echo ""
echo "Override the Agent Name, otherwise an Agent is created with the same"
echo "name as the GroupWise post office specified with the -p switch"
echo ""
echo "Example:             $0 -a server1 -p po1"
echo ""
echo "The Cimitra Agent \"SERVER1\" will service GroupWise"
echo "admin requests for the PO1 post office"
echo ""
echo "------------------------------"
echo "Exclude Installing or Checking for an Installed Cimitra Agent"
echo ""
echo "Example:             $0 -i ..."
echo ""
echo "------------------------------"
echo "Exclude GroupWise System Level Scripts"
echo ""
echo "Example:             $0 -s ..."
echo ""
echo "------------------------------"
echo ""
echo "[Cimitra GroupWise Helpdesk Post Office Import/UNINSTALL]"
echo ""
echo "Script usage:        $0 [options]"
echo ""
echo "Required Syntax:     $0 -u -p <GroupWise post office>"
echo ""
echo "Example:             $0 -u -p po1"
echo ""
echo "Verbose Mode:        $0 -v ..."
echo ""
echo "Help:                $0 -h"
echo ""
echo ""
echo "----SIMPLE HELP SCREEN------"
echo ""
echo "Import Post Office:  $0 -p <post office name>"
echo ""
echo "Example:  $0 -p po1"
echo ""
echo "-----------------------------"
echo ""

}

declare -i FIRST_INPUT_IS_HELP=`echo "$1" | grep -ic "help"`

if [ $FIRST_INPUT_IS_HELP -gt 0 ]
then
SHOW_HELP
exit 0
fi

declare -i FIRST_INPUT_IS_MENU=`echo "$1" | grep -ic "menu"`

if [ $FIRST_INPUT_IS_MENU -gt 0 ]
then
GET_CONFIGURATION_INFO="1"
fi

declare -i FIRST_INPUT_IS_TEST=`echo "$1" | grep -ic "test"`

if [ $FIRST_INPUT_IS_TEST -gt 0 ]
then
RUN_CONNECTION_TEST="1"
fi



function TEXT_EDITOR_REPLACE()
{
# TEXT_EDITOR_REPLACE "SETTING_NAME" "${SETTING_VARIABLE}" "$CONFIG_FILE"

declare -i ARG_ONE_EMPTY=`echo "$1" | wc -c`
declare -i ARG_TWO_EMPTY=`echo "$2" | wc -c`
declare -i ARG_THREE_EMPTY=`echo "$3" | wc -c`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

if [ $ARG_ONE_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_TWO_EMPTY -lt 2 ]
then
return
else
:
fi
if [ $ARG_THREE_EMPTY -lt 2 ]
then
return
else
:
fi

touch $3
declare -i LINES_PRIOR_TO_REMOVAL=`grep -c "=" $3`
declare -i EQUALS_EXIST=`grep -c "=" $3`

egrep -v "${1}=" $3 | sed '/^[[:space:]]*$/d' > ${TEMP_FILE_ONE}


declare -i LINES_AFTER_REMOVAL=`grep -c "=" ${TEMP_FILE_ONE}`
declare -i DIFFERENCE_OF_LINES_REMOVED=0
let DIFFERENCE_OF_LINES_REMOVED=LINES_PRIOR_TO_REMOVAL-LINES_AFTER_REMOVAL

if [ $DIFFERENCE_OF_LINES_REMOVED -gt 3 ]
then
rm ${TEMP_FILE_ONE}
echo ""
date
echo "It seems something is wrong, this setting change will not be made"
echo ""
fi


rm $3
mv ${TEMP_FILE_ONE} $3 
echo "${1}=\"${2}\"" >> $3

} # 2> /dev/null

function PROMPT_FOR_SETTINGS()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

LOCAL_IP=`ifconfig eth0 | grep "inet addr" | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1`

# Test to see if a number comes back
re='^[0-9]+$'
if ! [[ ${LOCAL_IP} =~ $re ]] 
then
LOCAL_IP="192.168.1.2"
fi

CIMITRA_SERVER_ADDRESS="${LOCAL_IP}"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

echo -e "\033[0;93m\033[44m[CIMITRA SERVER INFORMATION REQUIRED]"
echo -e "\033[0;93m\033[44m___________________________________________________"

if [ $CIMITRA_SERVER_ADDRESS_AND_PORT_REQUIRED -eq 1 ]
then
SUGGESTION="${CIMITRA_SERVER_ADDRESS}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER ADDRESS]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit address>\033[0;93m\033[0;92m"
read -p "Cimitra Server Address: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_API_ADDRESS" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_API_ADDRESS" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


CIMITRA_SERVER_PORT="443"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_PORT}"
echo -e "\033[0;93m\033[44m[CIMITRA SERVER PORT]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit port>\033[0;93m\033[0;92m"
read -p "Cimitra Server Port: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

declare -i HAS_ALPHA=`echo "${INPUT}" | grep -c '[[:alpha:]]'`
declare -i HAS_NUM=`echo "${INPUT}" | grep -c '[0-9]'`

	if [ $HAS_ALPHA -gt 0 ]
	then
	INPUT_VALID="0"
	fi

	if [ $HAS_NUM -lt 1 ]
	then
	INPUT_VALID="0"
	fi

	if [ $INPUT_LENGTH -lt 3 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_PORT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

fi

if [ $CIMITRA_SERVER_CREDENTIALS_REQUIRED -eq 1 ]
then
CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null
SUGGESTION="${CIMITRA_SERVER_ADMIN_ACCOUNT}"
echo -e "\033[0;93m\033[44m[ADMIN LEVEL USER ON CIMITRA SERVER]"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit user>\033[0;93m\033[0;92m"
read -p "Admin Level User: " -e -i ${SUGGESTION} INPUT

declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=`echo "${INPUT}" | grep -c "@"`

	if [ $INPUT_LENGTH -lt 4 ]
	then
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${SUGGESTION}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_ACCOUNT" "${INPUT}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi

CIMITRA_SERVER_ADMIN_PASSWORD="changeme"
source ${GW_SCRIPT_SETTINGS_FILE} 1> /dev/null 2> /dev/null

SUGGESTION="${CIMITRA_SERVER_ADMIN_PASSWORD}"
echo -e "\033[0;93m\033[44m[PASSWORD]\033[0;93m\033[44m"
echo -e "\033[0;93m\033[44m<Enter to accept, or edit password>\033[0;93m\033[0;92m"
# read -sp "Password: " INPUT

unset thePassword
echo -n "Password:  "
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${thePassword%?}"
    else
        prompt='*'
        thePassword+="$char"
    fi
done


declare -i INPUT_LENGTH=`echo "${INPUT}" | wc -m`
declare -i INPUT_VALID=1

	if [ $INPUT_LENGTH -lt 3 ]
	then
	:
	else
		if [ $INPUT_VALID -gt 0 ]
		then
		TEXT_EDITOR_REPLACE "CIMITRA_SERVER_ADMIN_PASSWORD" "${thePassword}" "${GW_SCRIPT_SETTINGS_FILE}"
		fi
	fi


}

if [ $GET_CONFIGURATION_INFO -eq 1 ]
then
CIMITRA_SERVER_CREDENTIALS_REQUIRED=1
CIMITRA_SERVER_ADDRESS_AND_PORT_REQUIRED=1
PROMPT_FOR_SETTINGS
# exit 0
fi

function PROCESS_CIMITRA_SETTINGS()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

declare -i CIMITRA_SERVER_PORT=0
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${CIMITRA_SERVER_PORT} -eq 0 ]]
then

LOCAL_IP=`ifconfig eth0 | grep "inet addr" | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1`

echo "CIMITRA_SERVER_ADDRESS=\"${LOCAL_IP}\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "CIMITRA_SERVER_PORT=\"443\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "CIMITRA_SERVER_API_ADDRESS=\"192.168.1.1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "CIMITRA_SERVER_API_PORT=\"5007\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "CIMITRA_SERVER_ADMIN_ACCOUNT=\"admin@cimitra.com\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "CIMITRA_SERVER_ADMIN_PASSWORD=\"changeme\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
CIMITRA_SERVER_CREDENTIALS_REQUIRED=1
CIMITRA_SERVER_ADDRESS_AND_PORT_REQUIRED=1
PROMPT_FOR_SETTINGS
echo ""
echo "Process: Now that you made settings changes, trying again" 
echo ""
# exit 1
fi


}

### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

if [ $RUN_CONNECTION_TEST -eq 1 ]
then
return
fi

let ALL_SET=+POST_OFFICE_IN_SET

if [ $ALL_SET -ne 1 ]
then
SHOW_HELP
# echo "NOTE: Insufficient Input To Run Script"
exit 1
fi
}





STUFF()
{

# Make Link
export CIMITRA_SERVER_ADDRESS="localhost" ; export CIMITRA_SERVER_PORT="5007" ; export CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com" ; export CIMITRA_SERVER_ADMIN_PASSWORD="changeme" ; export BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" ; export ENDPOINT="/users/login" ; export URL="${BASEURL}${ENDPOINT}" ; export DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}"  ; export RESPONSE=`curl -k -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"` ; export TOKEN=`echo ${RESPONSE} | awk -F \"token\":\" '{printf $2}' | awk -F \" '{printf $1}'` ; export USER_ID=`echo ${RESPONSE} | awk -F \"_id\":\" '{printf $2}' | awk -F \" '{printf $1}'` ; export ENDPOINT="/apps" ; export URL="${BASEURL}${ENDPOINT}" ; export CIMITRA_ROOT_FOLDER_ID=`curl -k -H 'Accept: application/json' -H "Authorization: Bearer ${TOKEN}" -X GET ${URL} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "_id:"  | head -1 | awk -F : '{printf $2}'` ; echo "{
    \"type\": 3,
    \"name\": \"Google\",
    \"description\": \"Google Home Page\",
    \"notes\": \"Google Search Engine\",
    \"url\": \"http://www.google.com\",
    \"status\": \"active\",
    \"parentFolderId\":  \"${CIMITRA_ROOT_FOLDER_ID}\"
}" 1> ./link.json ; curl -k -H 'Accept: application/json' \
-H "Authorization: Bearer ${TOKEN}" \
-X POST ${URL} -d @link.json \
-H"Content-Type: application/json"




#Make Agent

export CIMITRA_SERVER_ADDRESS="localhost" ; export CIMITRA_SERVER_PORT="5007" ; export CIMITRA_SERVER_ADMIN_ACCOUNT="admin@cimitra.com" ; export CIMITRA_SERVER_ADMIN_PASSWORD="changeme" ; export BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" ; export ENDPOINT="/users/login" ; export URL="${BASEURL}${ENDPOINT}" ; export DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}"  ; export RESPONSE=`curl -k -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"` ; export TOKEN=`echo ${RESPONSE} | awk -F \"token\":\" '{printf $2}' | awk -F \" '{printf $1}'` ; export USER_ID=`echo ${RESPONSE} | awk -F \"_id\":\" '{printf $2}' | awk -F \" '{printf $1}'` ; export ENDPOINT="/agent" ; export URL="${BASEURL}${ENDPOINT}" ; echo "{
    \"name\": \"CIMITRAPO\",
    \"description\": \"GWID:CIMITRADOM.CIMITRAPO\",
    \"platform\": \"linux\",
    \"match_regex\":  \"node01\"
}" 1> ./agent.json ; curl -k -H 'Accept: application/json' \
-H "Authorization: Bearer ${TOKEN}" \
-X POST ${URL} -d @agent.json \
-H"Content-Type: application/json"

}


function ESTABLISH_CIMITRA_API_SESSION()
{

source ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Process: Establishing Connection to Cimitra Server"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/users/login" 

URL="${BASEURL}${ENDPOINT}" 

DATA="{\"email\":\"${CIMITRA_SERVER_ADMIN_ACCOUNT}\",\"password\": \"${CIMITRA_SERVER_ADMIN_PASSWORD}\"}" 

{
RESPONSE=`curl -k -f -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"`
} 2> /dev/null

declare -i STATUS=`echo "${RESPONSE}" | grep -c ',\"homeFolderId\":\"'` 

if [ ${STATUS} -eq 0 ] 
then 
echo "--------------------------------------------------"
echo ""
curl -k ${CURL_OUTPUT_MODE} -H "Content-Type:application/json" -X POST ${URL} --data "$DATA"
echo ""
echo "--------------------------------------------------"
echo "" 
echo "Error: Could Not Establish Connection to Cimitra Server" 
declare -i CIMITRA_SERVER_CREDENTIALS_REQUIRED=1
PROMPT_FOR_SETTINGS
echo ""
echo "Process: Now that you made settings changes, trying again" 
echo ""
# exit 1 
fi 

CIMITRA_API_SESSION_TOKEN=`echo "${RESPONSE}" | awk -F \"token\":\" '{printf $2}' | awk -F \" '{printf $1}'`

echo ""
echo "Success: Established Connection to Cimitra Server"
echo ""
}



function CREATE_PAIRED_CIMITRA_AGENT()
{

if [ $CIMITRA_AGENT_IN_SET -eq 0 ]
then
AGENT_NAME="${POST_OFFICE_IN_UPPER}"
else
AGENT_NAME="${CIMITRA_AGENT_IN_UPPER}"
fi

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"
 
ENDPOINT="/agent" 

URL="${BASEURL}${ENDPOINT}" 


echo ""
echo "Process: Creating a new Cimitra Agent by the name of: ${AGENT_NAME}"

JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

SERVER_HOSTNAME=`hostname | tr [a-z] [A-Z]`

THE_DESCRIPTION="Cimitra Agent Deployed to Server: ${SERVER_HOSTNAME}\nIf you need to install the agent again folllow these 4 Simple Steps\n1. Download the Cimitra Agent and put it on the Linux server that hosts, post office: ${POST_OFFICE_IN_UPPER} \n2. Make the cimagent file executable: chmod +x ./cimagent\n3. Install the Cimitra Agent with the command: ./cimagent c\n4. Start the Cimitra Agent with the command: cimitra start"

echo "{
    \"name\": \"${AGENT_NAME}\",
    \"description\": \"${THE_DESCRIPTION}\",
    \"platform\": \"linux\",
    \"match_regex\":  \"node01\"
}" 1> ${JSON_TEMP_FILE_ONE} 


{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_TEMP_FILE_ONE}  \
-H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null

rm ${TEMP_FILE_DIRECTORY}/$$.tmp.agent.json 2> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

declare -i ERROR_STATE=`cat ${TEMP_FILE_TWO} | grep -c "error"`

if [ $ERROR_STATE -gt 0 ]
then
echo "" 
echo "Error: The maximum number of Cimitra Agents has been met" 
echo ""
echo "You must obtain a license to create more Cimitra Agents" 
echo ""
rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null
exit 1 
fi

echo ""
echo "Success: Created a new Cimitra Agent by the name of: ${AGENT_NAME}"

CIMITRA_PAIRED_AGENT_ID=`cat ${TEMP_FILE_TWO} | grep "_id:" | awk -F : '{printf $2}'`

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

}


function GET_URL()
{
IO_FILE="$1"

# Read values from IO File

source ${IO_FILE}

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

URL="${BASEURL}${ENDPOINT}" 

declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X GET ${URL}`

echo "$RESPONSE" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${IO_FILE}

return 0
}

function POST_URL()
{
IO_FILE="$1"

# Read values from IO File

source ${IO_FILE}

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_INPUT_FILE} \
-H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${IO_FILE}

rm ${JSON_INPUT_FILE} 2> /dev/null

return 0
}

function CREATE_CIMITRA_FOLDER_ENTITY()
{
IO_FILE=$1
NAME=$2
DESCRIPTION=$3
PARENT_FOLDER_ID=$4
# Define JSON temp file
JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

echo "{
    \"type\": 2,
    \"name\": \"${NAME}\",
    \"description\": \"${DESCRIPTION}\",
    \"status\": \"active\",
    \"parentFolderId\":  \"${PARENT_FOLDER_ID}\"
}" 1> ${JSON_TEMP_FILE_ONE}


# Define endpoint
ENDPOINT="/apps" 

# Add endoint and JSON temp file to I/O file
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
echo "JSON_INPUT_FILE=\"${JSON_TEMP_FILE_ONE}\"" >> ${TEMP_FILE_ONE}

# Call POST_URL Function
POST_URL "${IO_FILE}"
return 0
}


function CREATE_OR_DISCOVER_CIMITRA_GROUPWISE_ADMIN_FOLDER()
{

declare -i GROUPWISE_ADMIN_FOLDER_EXISTS=0

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ""
echo "Process: Discovering or Creating The GroupWise Admin Folder Structure"
ENDPOINT="/apps/${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}/children" 
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
GET_URL "${TEMP_FILE_ONE}"

# Determine if the "ADMIN" Folder Exists
declare -i ADMIN_FOLDER_EXISTS=`grep -ic "name:ADMIN" ${TEMP_FILE_ONE}`

if [ $ADMIN_FOLDER_EXISTS -gt 0 ]
then
echo ""
echo "Success: Discovered the Folder Structure ${CIMITRA_GROUPWISE_ROOT_FOLDER_NAME} | ADMIN"
GROUPWISE_ADMIN_FOLDER_ID=`grep -iwB 1 "name:ADMIN" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
fi

# Make the GROUPWISE | ADMIN Folder
if [ $ADMIN_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "ADMIN" "Admin Personnel" "${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}" 
GROUPWISE_ADMIN_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder Structure | ADMIN"
fi

rm ${TEMP_FILE_ONE} 2> /dev/null

}




function CREATE_OR_DISCOVER_CIMITRA_GROUPWISE_HELPDESK_FOLDER()
{

declare -i HELPDESK_FOLDER_EXISTS=0
declare -i HELPDESK_GROUPWISE_FOLDER_EXISTS=0
declare -i PO_FOLDER_EXISTS=0
declare -i USER_ACCESS_FOLDER_EXISTS=0
declare -i USER_CHANGES_FOLDER_EXISTS=0
declare -i USER_FIXES_FOLDER_EXISTS=0
declare -i USER_REPORTS_FOLDER_EXISTS=0
declare -i CREATE_FOLDER_EXISTS=0

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

###
if [ $HELPDESK_GROUPWISE_PO_FOLDER_ID_OBTAINED -eq 0 ]
then

echo ""
echo "Process: Discovering or Creating The GroupWise Helpdesk Folder Structure"
ENDPOINT="/apps/${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}/children" 
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
GET_URL "${TEMP_FILE_ONE}"

# Determine if the "HELPDESK" Folder Exists
declare -i HELPDESK_FOLDER_EXISTS=`grep -ic "name:HELPDESK" ${TEMP_FILE_ONE}`

if [ $HELPDESK_FOLDER_EXISTS -gt 0 ]
then
echo ""
echo "Success: Discovered the Folder Structure ${CIMITRA_GROUPWISE_ROOT_FOLDER_NAME} | HELPDESK"
HELPDESK_FOLDER_ID=`grep -iwB 1 "name:HELPDESK" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
fi

# Determine if the "GROUPWISE" Sub-Folder Exists under HELPDESK
if [ $HELPDESK_FOLDER_EXISTS -gt 0 ]
then
ENDPOINT="/apps/${HELPDESK_FOLDER_ID}/children" 
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
GET_URL "${TEMP_FILE_ONE}"
declare -i HELPDESK_GROUPWISE_FOLDER_EXISTS=`grep -ic "name:GROUPWISE" ${TEMP_FILE_ONE}`
fi

if [ $HELPDESK_GROUPWISE_FOLDER_EXISTS -gt 0 ]
then
HELPDESK_GROUPWISE_FOLDER_ID=`grep -iwB 1 "name:GROUPWISE" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Discovered the Folder Structure HELPDESK | GROUPWISE"
ENDPOINT="/apps/${HELPDESK_GROUPWISE_FOLDER_ID}/children" 
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
GET_URL "${TEMP_FILE_ONE}"
declare -i PO_FOLDER_EXISTS=`grep -ic "name:${POST_OFFICE_IN}" ${TEMP_FILE_ONE}`
fi

### 
fi

if [ $PO_FOLDER_EXISTS -gt 0 ]
then
echo ""
echo "Success: Discovered the Folder Structure ${POST_OFFICE_IN_UPPER}"
HELPDESK_GROUPWISE_PO_FOLDER_ID=`grep -iwB 1 "name:${POST_OFFICE_IN}" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
# Discover User Access Folder
ENDPOINT="/apps/${HELPDESK_GROUPWISE_PO_FOLDER_ID}/children" 
echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}
GET_URL "${TEMP_FILE_ONE}"
declare -i USER_ACCESS_FOLDER_EXISTS=`grep -ic "name:USER ACCESS" ${TEMP_FILE_ONE}`
declare -i USER_CHANGES_FOLDER_EXISTS=`grep -ic "name:USER CHANGES" ${TEMP_FILE_ONE}`
declare -i USER_FIXES_FOLDER_EXISTS=`grep -ic "name:USER FIXES" ${TEMP_FILE_ONE}`
declare -i USER_REPORTS_FOLDER_EXISTS=`grep -ic "name:USER REPORTS" ${TEMP_FILE_ONE}`
declare -i CREATE_FOLDER_EXISTS=`grep -ic "name:CREATE" ${TEMP_FILE_ONE}`
fi

if [ $USER_ACCESS_FOLDER_EXISTS -gt 0 ]
then
USER_ACCESS_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "USER ACCESS" | head -1 | awk -F : '{printf $2}'`
fi

if [ $USER_CHANGES_FOLDER_EXISTS -gt 0 ]
then
USER_CHANGES_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "USER CHANGES" | head -1 | awk -F : '{printf $2}'`
fi

if [ $USER_FIXES_FOLDER_EXISTS -gt 0 ]
then
USER_FIXES_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "USER FIXES" | head -1 | awk -F : '{printf $2}'`
fi

if [ $USER_REPORTS_FOLDER_EXISTS -gt 0 ]
then
USER_REPORTS_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "USER REPORTS" | head -1 | awk -F : '{printf $2}'`
fi

if [ $CREATE_FOLDER_EXISTS -gt 0 ]
then
CREATE_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "CREATE" | head -1 | awk -F : '{printf $2}'`
rm ${TEMP_FILE_ONE}
fi


# Make the GROUPWISE | HELPDESK Folder
if [ $HELPDESK_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "HELPDESK" "Helpdesk Personnel" "${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}" 
HELPDESK_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder HELPDESK"
fi

# Make the GROUPWISE | HELPDESK | GROUPWISE Folder
if [ $HELPDESK_GROUPWISE_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "GROUPWISE" "GroupWise Apps" "${HELPDESK_FOLDER_ID}" 
HELPDESK_GROUPWISE_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder GROUPWISE"
fi

# Make the GROUPWISE | HELPDESK | GROUPWISE | <POST OFFICE NAME> Folder

if [ $PO_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "${POST_OFFICE_IN_UPPER}" "Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_FOLDER_ID}" 
HELPDESK_GROUPWISE_PO_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder ${POST_OFFICE_IN_UPPER}"
fi

if [ $USER_ACCESS_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "USER ACCESS" "Change GroupWise User Account Access for Users in Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_PO_FOLDER_ID}" 
USER_ACCESS_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder USER ACCESS"
fi

if [ $USER_CHANGES_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "USER CHANGES" "Change GroupWise User Attributes in Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_PO_FOLDER_ID}" 
USER_CHANGES_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder USER CHANGES"
fi

if [ $USER_FIXES_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "USER FIXES" "Perform Fixes on Users in Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_PO_FOLDER_ID}" 
USER_FIXES_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder USER FIXES"
fi

if [ $USER_REPORTS_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "USER REPORTS" "Run Reports on Users in Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_PO_FOLDER_ID}" 
USER_REPORTS_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder USER REPORTS"
fi

if [ $CREATE_FOLDER_EXISTS -eq 0 ]
then
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "CREATE" "Create Objects on Post Office: ${POST_OFFICE_IN_UPPER}" "${HELPDESK_GROUPWISE_PO_FOLDER_ID}" 
CREATE_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder CREATE"
fi


rm ${TEMP_FILE_ONE} 2> /dev/null

}


function CREATE_OR_DISOVER_GROUPWISE_FOLDER_STRUCTURE()
{

ENDPOINT="/apps" 

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_ONE}

GET_URL "${TEMP_FILE_ONE}"

CIMITRA_USERID=`echo ${CIMITRA_SERVER_ADMIN_ACCOUNT} | awk -F \@ '{printf $1}'`

ROOT_FOLDER_NAME="name:Home Folder - ${CIMITRA_USERID}"

CIMITRA_ROOT_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "${ROOT_FOLDER_NAME}" | head -1 | awk -F : '{printf $2}'`

if [ $FOLDER_ID_IN_SET -eq 0 ]
then
SEARCH_FOR="CIMITRA_IMPORT:GROUPWISE_MAIN_FOLDER"
else
SEARCH_FOR="${FOLDER_ID}"
fi

declare -i GROUPWISE_ROOT_FOLDER_EXISTS=`cat ${TEMP_FILE_ONE} | grep -c "${SEARCH_FOR}"`


if [ $GROUPWISE_ROOT_FOLDER_EXISTS -eq 1 ]
then
CIMITRA_GROUPWISE_ROOT_FOLDER_ID=`cat ${TEMP_FILE_ONE} | grep -iwB 2 "${SEARCH_FOR}" | head -1 | awk -F : '{printf $2}'`
CIMITRA_GROUPWISE_ROOT_FOLDER_NAME=`cat ${TEMP_FILE_ONE} | grep -iwB 1 "${SEARCH_FOR}" | head -1 | awk -F : '{printf $2}'`
echo "Success: Identified the GroupWise Folder For Creating Cimitra Folders and Apps"
echo ""
echo "Success: The Folder Name is: ${CIMITRA_GROUPWISE_ROOT_FOLDER_NAME}"
else
CIMITRA_ROOT_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
CREATE_CIMITRA_FOLDER_ENTITY "${TEMP_FILE_ONE}" "GROUPWISE" "CIMITRA_IMPORT:GROUPWISE_MAIN_FOLDER" "${CIMITRA_ROOT_FOLDER_ID}" 
CIMITRA_GROUPWISE_ROOT_FOLDER_ID=`grep "_id:" ${TEMP_FILE_ONE} | head -1 | awk -F : '{printf $2}'`
echo ""
echo "Success: Created the Folder GROUPWISE"
fi


rm ${TEMP_FILE_ONE} 2> /dev/null

CREATE_OR_DISCOVER_CIMITRA_GROUPWISE_ADMIN_FOLDER

if [ $CREATE_SUB_FOLDER_STRUCTURE -eq 0 ]
then
HELPDESK_GROUPWISE_PO_FOLDER_ID_OBTAINED=1
HELPDESK_GROUPWISE_PO_FOLDER_ID="$CIMITRA_GROUPWISE_ROOT_FOLDER_ID"
fi

CREATE_OR_DISCOVER_CIMITRA_GROUPWISE_HELPDESK_FOLDER

}


function CHECK_FOR_EXISTING_APP()
{
PARENT_FOLDER_ID=$1
APP_SCRIPT=$2

ENDPOINT="/apps/${PARENT_FOLDER_ID}/children" 

echo "ENDPOINT=\"${ENDPOINT}\"" > ${TEMP_FILE_TWO}

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

GET_URL "${TEMP_FILE_TWO}"

# Determine if the script exists
declare -i SCRIPT_ALREADY_EXISTS=`grep -ic "${APP_SCRIPT}" ${TEMP_FILE_TWO}`
rm ${TEMP_FILE_TWO} 2> /dev/null
if [ $SCRIPT_ALREADY_EXISTS -gt 0 ]
then
return 1
else
return 0
fi
}

function CIMITRA_APP_CREATE_NO_INPUTS()
{

IO_FILE="$1"

source ${IO_FILE}

APP_SCRIPT=`basename ${COMMAND}`

SCRIPT_EXISTS=`CHECK_FOR_EXISTING_APP "${PARENT_FOLDER_ID}" "${APP_SCRIPT}" ; echo $?`


if [ $SCRIPT_EXISTS -eq 1 ]
then
rm ${IO_FILE} 2> /dev/null
return
fi


JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/apps" 

URL="${BASEURL}${ENDPOINT}"

source ${IO_FILE}

rm ${IO_FILE}

echo "{
\"type\": 1,
\"status\": \"active\",
\"name\": \"${NAME}\",
\"parentFolderId\":  \"${PARENT_FOLDER_ID}\",
\"description\": \"${DESCRIPTION}\",
\"platform\": \"linux\",
\"agentId\": \"${CIMITRA_PAIRED_AGENT_ID}\",
\"interpreter\": \"/bin/bash\",
\"command\": \"${COMMAND}\",
\"params\": \"${PARAMS}\",
\"notes\": \"${NOTES}\",
\"injectParams\": []
}" 1> ${JSON_TEMP_FILE_ONE}

{
RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_TEMP_FILE_ONE} \
-H "Content-Type: application/json"` 
} 1> /dev/null 2> /dev/null



rm ${JSON_TEMP_FILE_ONE} 2> /dev/null

}

function CIMITRA_APP_CREATE_TWO_INPUTS()
{

IO_FILE="$1"

source ${IO_FILE}

APP_SCRIPT=`basename ${COMMAND}`

SCRIPT_EXISTS=`CHECK_FOR_EXISTING_APP "${PARENT_FOLDER_ID}" "${APP_SCRIPT}" ; echo $?`

if [ $SCRIPT_EXISTS -eq 1 ]
then
rm ${IO_FILE} 2> /dev/null
return
fi

JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/apps" 

URL="${BASEURL}${ENDPOINT}"

source ${IO_FILE}

rm ${IO_FILE}

echo "{
\"type\": 1,
\"status\": \"active\",
\"name\": \"${NAME}\",
\"parentFolderId\":  \"${PARENT_FOLDER_ID}\",
\"description\": \"${DESCRIPTION}\",
\"platform\": \"linux\",
\"agentId\": \"${CIMITRA_PAIRED_AGENT_ID}\",
\"interpreter\": \"/bin/bash\",
\"command\": \"${COMMAND}\",
\"params\": \"${PARAMS}\",
\"notes\": \"${NOTES}\",
\"injectParams\": [
{
\"param\": \"${IP1_PARAM}\",
\"value\": \"${IP1_VALUE}\",
\"label\": \"${IP1_LABEL}\",
\"placeholder\": \"${IP1_PLACEHOLDER}\",
\"private\": ${IP1_PRIVATE},
\"regex\": \"${IP1_REGEX}\"
},
{
\"param\": \"${IP2_PARAM}\",
\"value\": \"${IP2_VALUE}\",
\"label\": \"${IP2_LABEL}\",
\"placeholder\": \"${IP2_PLACEHOLDER}\",
\"private\": ${IP2_PRIVATE},
\"regex\": \"${IP2_REGEX}\"
}
]
}" 1> ${JSON_TEMP_FILE_ONE}


{
RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_TEMP_FILE_ONE} \
-H "Content-Type: application/json"` 
} 1> /dev/null 2> /dev/null


rm ${JSON_TEMP_FILE_ONE} 2> /dev/null

}



function CIMITRA_APP_CREATE_FOUR_INPUTS()
{

IO_FILE="$1"

source ${IO_FILE}

APP_SCRIPT=`basename ${COMMAND}`

SCRIPT_EXISTS=`CHECK_FOR_EXISTING_APP "${PARENT_FOLDER_ID}" "${APP_SCRIPT}" ; echo $?`

if [ $SCRIPT_EXISTS -eq 1 ]
then
rm ${IO_FILE} 2> /dev/null
return
fi

JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/apps" 

URL="${BASEURL}${ENDPOINT}"

source ${IO_FILE}

rm ${IO_FILE}

echo "{
\"type\": 1,
\"status\": \"active\",
\"name\": \"${NAME}\",
\"parentFolderId\":  \"${PARENT_FOLDER_ID}\",
\"description\": \"${DESCRIPTION}\",
\"platform\": \"linux\",
\"agentId\": \"${CIMITRA_PAIRED_AGENT_ID}\",
\"interpreter\": \"/bin/bash\",
\"command\": \"${COMMAND}\",
\"params\": \"${PARAMS}\",
\"notes\": \"${NOTES}\",
\"injectParams\": [
{
\"param\": \"${IP1_PARAM}\",
\"value\": \"${IP1_VALUE}\",
\"label\": \"${IP1_LABEL}\",
\"placeholder\": \"${IP1_PLACEHOLDER}\",
\"private\": ${IP1_PRIVATE},
\"regex\": \"${IP1_REGEX}\"
},
{
\"param\": \"${IP2_PARAM}\",
\"value\": \"${IP2_VALUE}\",
\"label\": \"${IP2_LABEL}\",
\"placeholder\": \"${IP2_PLACEHOLDER}\",
\"private\": ${IP2_PRIVATE},
\"regex\": \"${IP2_REGEX}\"
},
{
\"param\": \"${IP3_PARAM}\",
\"value\": \"${IP3_VALUE}\",
\"label\": \"${IP3_LABEL}\",
\"placeholder\": \"${IP3_PLACEHOLDER}\",
\"private\": ${IP3_PRIVATE},
\"regex\": \"${IP3_REGEX}\"
},
{
\"param\": \"${IP4_PARAM}\",
\"value\": \"${IP4_VALUE}\",
\"label\": \"${IP4_LABEL}\",
\"placeholder\": \"${IP4_PLACEHOLDER}\",
\"private\": ${IP4_PRIVATE},
\"regex\": \"${IP4_REGEX}\"
}
]
}" 1> ${JSON_TEMP_FILE_ONE}


{
RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_TEMP_FILE_ONE} \
-H "Content-Type: application/json"` 
} 1> /dev/null 2> /dev/null


rm ${JSON_TEMP_FILE_ONE} 2> /dev/null

}


function CREATE_CIMITRA_APP()
{
IO_FILE="$1"

declare -i INJECTABLE_PARAMETERS_ENABLED=0

source ${IO_FILE}

APP_SCRIPT=`basename ${COMMAND}`

SCRIPT_EXISTS=`CHECK_FOR_EXISTING_APP "${PARENT_FOLDER_ID}" "${APP_SCRIPT}" ; echo $?`

if [ $SCRIPT_EXISTS -eq 1 ]
then
rm ${IO_FILE} 2> /dev/null
return
fi

if [ $INJECTABLE_PARAMETERS_ENABLED -eq 0 ]
then
CIMITRA_APP_CREATE_NO_INPUTS "${IO_FILE}"
return
fi

if [ $INJECTABLE_PARAMETERS_ENABLED -eq 2 ]
then
CIMITRA_APP_CREATE_TWO_INPUTS "${IO_FILE}"
return
fi


JSON_TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.json"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api" 

ENDPOINT="/apps" 

URL="${BASEURL}${ENDPOINT}"

source ${IO_FILE}

rm ${IO_FILE}


echo -n "{
    \"type\": 1,
    \"name\": \"${NAME}\",
    \"description\": \"${DESCRIPTION}\",
    \"notes\": \"${NOTES}\",
    \"platform\": \"${PLATFORM}\",
    \"agentId\": \"${CIMITRA_PAIRED_AGENT_ID}\",
	\"interpreter\": \"/bin/bash\",
	\"command\": \"${COMMAND}\",
	\"params\": \"${PARAMS}\",
    \"status\": \"active\"," 1> ${JSON_TEMP_FILE_ONE}

echo -n "\"parentFolderId\":  \"${PARENT_FOLDER_ID}\"" 1>> ${JSON_TEMP_FILE_ONE}

if [ $INJECTABLE_PARAMETERS_ENABLED -gt 0 ]
then
echo "," 1>> ${JSON_TEMP_FILE_ONE}
else
echo "}" 1>> ${JSON_TEMP_FILE_ONE}
fi

if [ $INJECTABLE_PARAMETERS_ENABLED -gt 0 ]
then

declare -i COUNTER=1

echo -n "\"injectParams\": [" 1>> ${JSON_TEMP_FILE_ONE}


while [ $COUNTER -le $INJECTABLE_PARAMETERS_ENABLED ]
do

case ${COUNTER} in
1)
PARAM="${IP1_PARAM}"
VALUE="${IP1_VALUE}"
LABEL="${IP1_LABEL}"
PLACEHOLDER="${IP1_PLACEHOLDER}"
PRIVATE="${IP1_PRIVATE}"
TYPE="${IP1_TYPE}"
REGEX="${IP1_REGEX}"
;;
2)
PARAM="${IP2_PARAM}"
VALUE="${IP2_VALUE}"
LABEL="${IP2_LABEL}"
PLACEHOLDER="${IP2_PLACEHOLDER}"
PRIVATE="${IP2_PRIVATE}"
TYPE="${IP2_TYPE}"
REGEX="${IP2_REGEX}"
;;
esac

	if [ $COUNTER -eq 1 ]
	then
		echo -n "{\"param\": \"${PARAM}\",
		\"value\": \"${VALUE}\",
		\"label\": \"${LABEL}\",
		\"placeholder\": \"${PLACEHOLDER}\",
		\"private\": ${PRIVATE},
		\"regex\": \"${REGEX}\"
		}" 1>> ${JSON_TEMP_FILE_ONE}
	else
		echo -n               "{\"param\": \"${PARAM}\",
		\"value\": \"${VALUE}\",
		\"label\": \"${LABEL}\",
		\"placeholder\": \"${PLACEHOLDER}\",
		\"private\": ${PRIVATE},
		\"regex\": \"${REGEX}\"
		}" 1>> ${JSON_TEMP_FILE_ONE}
	fi

let COUNTER=COUNTER+1

	if [ ${COUNTER} -le ${INJECTABLE_PARAMETERS_ENABLED} ]
	then
	echo "," 1>> ${JSON_TEMP_FILE_ONE}
	fi

done

echo "]" 1>> ${JSON_TEMP_FILE_ONE}
echo "}" 1>> ${JSON_TEMP_FILE_ONE}

fi

{
RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} -d @${JSON_TEMP_FILE_ONE} \
-H "Content-Type: application/json"` 
} 1> /dev/null 2> /dev/null


rm ${JSON_TEMP_FILE_ONE} 2> /dev/null

}

function CREATE_NO_INPUT_SYSTEM_APP()
{

APP_SCRIPT="$1"
APP_NAME="$2"
APP_DESCRIPTION="$3"
PARENT_FOLDER_ID="$4"
OPTIONAL_SWITCHES="$5"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"${APP_NAME}\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"${APP_DESCRIPTION}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/${APP_SCRIPT}\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"${OPTIONAL_SWITCHES}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${PARENT_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}
echo "INJECTABLE_PARAMETERS_ENABLED=\"0\"" >> ${TEMP_FILE_ONE}


CIMITRA_APP_CREATE_NO_INPUTS ${TEMP_FILE_ONE}

}

function CREATE_NO_INPUT_APP()
{

APP_SCRIPT="$1"
APP_NAME="$2"
APP_DESCRIPTION="$3"
PARENT_FOLDER_ID="$4"
OPTIONAL_SWITCHES="$5"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"${APP_NAME}\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"${APP_DESCRIPTION}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/${APP_SCRIPT}\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"${OPTIONAL_SWITCHES} -p ${POST_OFFICE_IN}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${PARENT_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}
echo "INJECTABLE_PARAMETERS_ENABLED=\"0\"" >> ${TEMP_FILE_ONE}


CIMITRA_APP_CREATE_NO_INPUTS ${TEMP_FILE_ONE}

}

function CREATE_ONE_INPUT_APP()
{

APP_SCRIPT="$1"
APP_NAME="$2"
APP_DESCRIPTION="$3"
PARENT_FOLDER_ID="$4"
IP1_LABEL="$5"
IP1_PLACEHOLDER="$6"
IP1_PRIVATE="$7"
IP1_REGEX="$8"


TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"${APP_NAME}\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"${APP_DESCRIPTION}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/${APP_SCRIPT}\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"${ADDITIONAL_APP_PARAMETER} -p ${POST_OFFICE_IN}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${PARENT_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}
echo "INJECTABLE_PARAMETERS_ENABLED=\"1\"" >> ${TEMP_FILE_ONE}

echo "IP1_PARAM=\"-i\"" >> ${TEMP_FILE_ONE}
echo "IP1_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP1_LABEL=\"${IP1_LABEL}\"" >> ${TEMP_FILE_ONE}
echo "IP1_PLACEHOLDER=\"${IP1_PLACEHOLDER}\"" >> ${TEMP_FILE_ONE}
echo "IP1_PRIVATE=\"${IP1_PRIVATE}\"" >> ${TEMP_FILE_ONE}
echo "IP1_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP1_REGEX=\"${IP1_REGEX}\"" >> ${TEMP_FILE_ONE}

ADDITIONAL_APP_PARAMETER=""

CREATE_CIMITRA_APP ${TEMP_FILE_ONE}



}

function CREATE_USER_AND_NO_INPUT_APP()
{
APP_SCRIPT="$1"
APP_NAME="$2"
APP_DESCRIPTION="$3"
PARENT_FOLDER_ID="$4"
declare -i USER_ID_PLURAL="$5"

if [ $USER_ID_PLURAL -eq 0 ]
then
IP1_LABEL="USERID"
else
IP1_LABEL="USERID(S)"
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"${APP_NAME}\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"${APP_DESCRIPTION}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/${APP_SCRIPT}\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"-p ${POST_OFFICE_IN}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${PARENT_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}
echo "INJECTABLE_PARAMETERS_ENABLED=\"1\"" >> ${TEMP_FILE_ONE}

echo "IP1_PARAM=\"-u\"" >> ${TEMP_FILE_ONE}
echo "IP1_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP1_LABEL=\"${IP1_LABEL}\"" >> ${TEMP_FILE_ONE}
echo "IP1_PLACEHOLDER=\"jdoe\"" >> ${TEMP_FILE_ONE}
echo "IP1_PRIVATE=\"false\"" >> ${TEMP_FILE_ONE}
echo "IP1_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP1_REGEX=\"/^[A-Za-z-_0-9 ]+$/\"" >> ${TEMP_FILE_ONE}

CREATE_CIMITRA_APP ${TEMP_FILE_ONE}

}

function CREATE_ONLY_USER_AND_ONE_INPUT_APP()
{
APP_SCRIPT="$1"
APP_NAME="$2"
APP_DESCRIPTION="$3"
PARENT_FOLDER_ID="$4"
declare -i USER_ID_PLURAL="$5"
IP2_LABEL="$6"
IP2_PLACEHOLDER="$7"
IP2_PRIVATE="$8"
IP2_REGEX="$9"

if [ $USER_ID_PLURAL -eq 0 ]
then
IP1_LABEL="USERID"
else
IP1_LABEL="USERID(S)"
fi

if [ $CREATE_APP_ADDITIONAL_INPUT_ON -gt 0 ]
then
IP1_LABEL="${CREATE_APP_ADDITIONAL_INPUT_VALUE}"
CREATE_APP_ADDITIONAL_INPUT_ON="0"
CREATE_APP_ADDITIONAL_INPUT_VALUE=""
fi
 
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"${APP_NAME}\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"${APP_DESCRIPTION}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/${APP_SCRIPT}\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"${ADDITIONAL_APP_PARAMETER} ${CREATE_ONLY_USER_AND_ONE_INPUT_APP_ADDITIONAL_PARAMETER_VALUE} -p ${POST_OFFICE_IN}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${PARENT_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}
echo "INJECTABLE_PARAMETERS_ENABLED=\"2\"" >> ${TEMP_FILE_ONE}

echo "IP1_PARAM=\"-u\"" >> ${TEMP_FILE_ONE}
echo "IP1_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP1_LABEL=\"${IP1_LABEL}\"" >> ${TEMP_FILE_ONE}
echo "IP1_PLACEHOLDER=\"jdoe\"" >> ${TEMP_FILE_ONE}
echo "IP1_PRIVATE=\"false\"" >> ${TEMP_FILE_ONE}
echo "IP1_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP1_REGEX=\"/^[A-Za-z-_0-9 ]+$/\"" >> ${TEMP_FILE_ONE}

echo "IP2_PARAM=\"-i\"" >> ${TEMP_FILE_ONE}
echo "IP2_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP2_LABEL=\"${IP2_LABEL}\"" >> ${TEMP_FILE_ONE}
echo "IP2_PLACEHOLDER=\"${IP2_PLACEHOLDER}\"" >> ${TEMP_FILE_ONE}
echo "IP2_PRIVATE=\"${IP2_PRIVATE}\"" >> ${TEMP_FILE_ONE}
echo "IP2_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP2_REGEX=\"${IP2_REGEX}\"" >> ${TEMP_FILE_ONE}

ADDITIONAL_APP_PARAMETER=""

CREATE_CIMITRA_APP ${TEMP_FILE_ONE}

}

function CREATE_APP_CREATE_USER_OBJECT()
{

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo "NAME=\"CREATE USER\"" > ${TEMP_FILE_ONE}
echo "DESCRIPTION=\"Create a GroupWise User Mailbox in Post Office: ${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "NOTES=\"${POST_OFFICE_IN_UPPER}\"" >> ${TEMP_FILE_ONE}
echo "PLATFORM=\"linux\"" >> ${TEMP_FILE_ONE}
echo "COMMAND=\"${CURRENT_WORKING_DIRECTORY}/gw_user_create.sh\"" >> ${TEMP_FILE_ONE}
echo "PARAMS=\"-o 4 -p ${POST_OFFICE_IN}\"" >> ${TEMP_FILE_ONE}
echo "PARENT_FOLDER_ID=\"${CREATE_FOLDER_ID}\"" >> ${TEMP_FILE_ONE}

echo "IP1_PARAM=\"-u\"" >> ${TEMP_FILE_ONE}
echo "IP1_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP1_LABEL=\"USERID\"" >> ${TEMP_FILE_ONE}
echo "IP1_PLACEHOLDER=\"jdoe\"" >> ${TEMP_FILE_ONE}
echo "IP1_PRIVATE=\"false\"" >> ${TEMP_FILE_ONE}
echo "IP1_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP1_REGEX=\"/^[A-Za-z-_0-9 ]+$/\"" >> ${TEMP_FILE_ONE}

echo "IP2_PARAM=\"-f\"" >> ${TEMP_FILE_ONE}
echo "IP2_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP2_LABEL=\"FIRST NAME\"" >> ${TEMP_FILE_ONE}
echo "IP2_PLACEHOLDER=\"Jane\"" >> ${TEMP_FILE_ONE}
echo "IP2_PRIVATE=\"false\"" >> ${TEMP_FILE_ONE}
echo "IP2_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP2_REGEX=\"/^[A-Za-z-_0-9 ]+$/\"" >> ${TEMP_FILE_ONE}

echo "IP3_PARAM=\"-l\"" >> ${TEMP_FILE_ONE}
echo "IP3_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP3_LABEL=\"LAST NAME\"" >> ${TEMP_FILE_ONE}
echo "IP3_PLACEHOLDER=\"Doe\"" >> ${TEMP_FILE_ONE}
echo "IP3_PRIVATE=\"false\"" >> ${TEMP_FILE_ONE}
echo "IP3_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP3_REGEX=\"/^[A-Za-z-_0-9 ]+$/\"" >> ${TEMP_FILE_ONE}

echo "IP4_PARAM=\"-c\"" >> ${TEMP_FILE_ONE}
echo "IP4_VALUE=\"\"" >> ${TEMP_FILE_ONE}
echo "IP4_LABEL=\"PASSWORD\"" >> ${TEMP_FILE_ONE}
echo "IP4_PLACEHOLDER=\"\"" >> ${TEMP_FILE_ONE}
echo "IP4_PRIVATE=\"true\"" >> ${TEMP_FILE_ONE}
echo "IP4_TYPE=\"1\"" >> ${TEMP_FILE_ONE}
echo "IP4_REGEX=\"/^[A-Za-z-_0-9+#=]+$/\"" >> ${TEMP_FILE_ONE}

CIMITRA_APP_CREATE_FOUR_INPUTS ${TEMP_FILE_ONE}
}

function CREATE_CIMITRA_TITLE_APP()
{
ADDITIONAL_APP_PARAMETER=""

CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_title.sh" "TITLE" "Change a user's Title in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1" "TITLE" "Accountant" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_PHONE_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_phone.sh" "PHONE NUMBER" "Change a user's Office Phone Number in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "0" "PHONE NUMBER ( Use This Syntax: 801-555-1212 )" "801-555-1212" "false" "/^[0-9- ]+$/"
}

function CREATE_CIMITRA_DEPARTMENT_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_department.sh" "DEPARTMENT" "Change a user's Department in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1" "DEPARTMENT" "Accounting" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_GROUP_LIST_USERS_APP()
{
CREATE_ONE_INPUT_APP "gw_group_list_users.sh" "LIST USERS IN A GROUP" "List all of the users in a Group on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "GROUP" "Accounting Group" "false" "/^[A-Za-z-_0-9# ]+$/"
}

# FIX USER APPS

function CREATE_USER_MAILBOX_SYNC_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_sync.sh" "SYNCHRONIZE USER" "Use this App to Synchronize the account for a user in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_FIXES_FOLDER_ID}" "1"
}

function CREATE_USER_MAILBOX_GWCHECK_STRUCTURE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_gwcheck_structure.sh" "FIX MAILBOX" "Use this App to fix the database for a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_FIXES_FOLDER_ID}" "1"
}

function CREATE_USER_QUICKFINDER_REBUILD_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_quickfinder.sh" "FIX MAILBOX SEARCH ISSUES" "Use this App to fix the search index for a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_FIXES_FOLDER_ID}" "1"
}
# USER ACCESS APPS
function CREATE_USER_MAILBOX_STATS_ACCESS_FOLDER_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_mailbox_stats.sh" "ACCOUNT INFORMATION" "Use this App to get the Mailbox Information for a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_MAILBOX_STATS_CHANGES_FOLDER_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_mailbox_stats.sh" "ACCOUNT INFORMATION" "Use this App to get the Mailbox Information for a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1"
}

function CREATE_USER_PASSWORD_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_password.sh" "CHANGE PASSWORD" "Use this App to Set a Password for a User's Account on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1" "PASSWORD" "Sup3rS3kr3t" "true" "/^[A-Za-z-_0-9+#=]+$/"
}

function CREATE_USER_ENABLE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_enable.sh" "ENABLE LOGIN" "Use this App to Enable Login Access to a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_DISABLE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_disable.sh" "DISABLE LOGIN" "Use this App to Disable Login Access to a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_ACTIVE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_active.sh" "ACTIVATE ACCOUNT" "Use this App to Activate a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_INACTIVE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_inactive.sh" "DEACTIVATE ACCOUNT" "Use this App to Deactivate a user's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_EXPIRE_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_expire.sh" "SET ACCOUNT EXPIRE DATE" "Use this App to Set an Expiration Date for a User's Account on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1" "DATE ( Use This Syntax: 4-15-2020 | Which means April 15th, 2020 )" "4-15-2020" "false" "/^[0-9- ]+$/"
}

function CREATE_USER_UNEXPIRE_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_expire_off.sh" "REMOVE ACCOUNT EXPIRATION" "Use this App to Remove an Expiration Date on a User's mailbox on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1"
}

function CREATE_USER_VISIBILITY_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_visibility.sh" "CHANGE USER VISIBILITY" "Use this App to Set the Visibility for a User's Account on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_ACCESS_FOLDER_ID}" "1" "Number: 1, 2, 3, or 4" "VISIBILITY ( 1 = None, 2 = Post Office, 3 = Domain, 4 = System )" "false" "/^[1-4]+$/" 
}

function CREATE_CIMITRA_GROUP_ADD_USER_APP()
{
ADDITIONAL_APP_PARAMETER="-q ${POST_OFFICE_IN_LOWER}"

CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_group_add_user.sh" "ADD USER TO A GROUP" "Use this App to Add a User to a Group on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1" "GROUP" "Accounting Group" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_GROUP_REMOVE_USER_APP()
{
ADDITIONAL_APP_PARAMETER="-q ${POST_OFFICE_IN_LOWER}"

CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_group_remove_user.sh" "REMOVE USER FROM GROUP" "Use this App Remove a User from a Group on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1" "GROUP" "Accounting Group" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_LIST_GROUPS_IN_POST_OFFICE_APP()
{
CREATE_NO_INPUT_APP "gw_po_list_groups.sh" "LIST GROUPS" "Use this App to List All Groups in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}"
}

function CREATE_CIMITRA_FIRST_NAME_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_first_name.sh" "CHANGE FIRST NAME" "Change a user's First Name in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "0" "NEW FIRST NAME" "Jane" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_LAST_NAME_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_last_name.sh" "CHANGE LAST NAME" "Change a user's Last Name in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "0" "NEW LAST NAME" "Doe" "false" "/^[A-Za-z-_0-9# ]+$/"
}

function CREATE_CIMITRA_USERID_CHANGE_APP()
{
CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_user_userid_change.sh" "RENAME USERID" "Change a user's USERID in Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "0" "NEW USERID" "doej" "false" "/^[A-Za-z-_0-9]+$/"
}

# POST OFFICE REPORTS

function CREATE_USER_GROUP_REPORT_APP()
{
CREATE_USER_AND_NO_INPUT_APP "gw_user_group_report.sh" "USER GROUP MEMBERSHIP REPORT" "List all the Groups a User is a member of on the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_CHANGES_FOLDER_ID}" "1"
}

function CREATE_PO_PHONE_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_APP "gw_po_list_telephones.sh" "ALL USERS PHONE NUMBERS" "Use this App to List All Users and their Office Phone Numbers in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}

function CREATE_PO_PHONE_REPORT_ALL_PHONES()
{
CREATE_NO_INPUT_APP "gw_po_list_telephones_only.sh" "ONLY USERS WITH PHONE NUMBER" "Use this App to List Only Users With Office Phone Numbers in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}" 
}

function CREATE_PO_PHONE_REPORT_NO_PHONES()
{
CREATE_NO_INPUT_APP "gw_po_list_telephones_none.sh" "USERS WITH NO PHONE NUMBER" "Use this App to List Only Users Without Office Phone Numbers in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}

function CREATE_PO_TITLE_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_APP "gw_po_list_titles.sh" "ALL USERS TITLES" "Use this App to List All Users and their Titles in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}

function CREATE_PO_TITLE_REPORT_ALL_TITLES()
{
CREATE_NO_INPUT_APP "gw_po_list_titles_only.sh" "ONLY USERS WITH A TITLE" "Use this App to List Only Users With Titles in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}" 
}

function CREATE_PO_TITLE_REPORT_NO_TITLES()
{
CREATE_NO_INPUT_APP "gw_po_list_titles_none.sh" "USERS WITH NO TITLE" "Use this App to List Users Without Titles in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}

function CREATE_PO_DEPARTMENT_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_APP "gw_po_list_departments.sh" "ALL USERS DEPARTMENTS" "Use this App to List All Users and their Departments in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}

function CREATE_PO_DEPARTMENT_REPORT_ALL_DEPARTMENTS()
{
CREATE_NO_INPUT_APP "gw_po_list_departments_only.sh" "ONLY USERS WITH A DEPARTMENT" "Use this App to List Only Users With Departments in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}" 
}

function CREATE_PO_DEPARTMENT_REPORT_NO_DEPARTMENTS()
{
CREATE_NO_INPUT_APP "gw_po_list_departments_none.sh" "USERS WITH NO DEPARTMENT" "Use this App to List Users Without Departments in the Post Office: ${POST_OFFICE_IN_UPPER}" "${USER_REPORTS_FOLDER_ID}"
}


# ADMIN SYSTEM REPORTS

function CREATE_SYSTEM_PHONE_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_telephones.sh" "ALL USERS PHONE NUMBERS" "Use this App to List All Users and their Office Phone Numbers in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_PHONE_REPORT_ALL_PHONES()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_telephones_only.sh" "ONLY USERS WITH PHONE NUMBER" "Use this App to List Only Users With Office Phone Numbers in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}" 
}

function CREATE_SYSTEM_PHONE_REPORT_NO_PHONES()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_telephones_none.sh" "USERS WITH NO PHONE NUMBER" "Use this App to List Only Users Without Office Phone Numbers in the the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_TITLE_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_titles.sh" "ALL USERS TITLES" "Use this App to List All Users and their Titles in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_TITLE_REPORT_ALL_TITLES()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_titles_only.sh" "ONLY USERS WITH A TITLE" "Use this App to List Only Users With Titles in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}" 
}

function CREATE_SYSTEM_TITLE_REPORT_NO_TITLES()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_titles_none.sh" "USERS WITH NO TITLE" "Use this App to List Users Without Titles in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_USERS()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_departments.sh" "ALL USERS DEPARTMENTS" "Use this App to List All Users and their Departments in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_DEPARTMENTS()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_departments_only.sh" "ONLY USERS WITH A DEPARTMENT" "Use this App to List Only Users With Departments in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}" 
}

function CREATE_SYSTEM_DEPARTMENT_REPORT_NO_DEPARTMENTS()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_departments_none.sh" "USERS WITH NO DEPARTMENT" "Use this App to List Users Without Departments in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

function CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_NICKNAMES()
{
CREATE_NO_INPUT_SYSTEM_APP "gw_system_list_nicknames.sh" "ALL NICKNAMES" "Use this App to List All Nicknames in the GroupWise System" "${GROUPWISE_ADMIN_FOLDER_ID}"
}

# OBJECT CREATION APPS

function CREATE_APP_CREATE_RESOURCE_OBJECT()
{
declare -i CREATE_APP_ADDITIONAL_INPUT_ON=1

ADDITIONAL_APP_PARAMETER="-o 4"

declare CREATE_APP_ADDITIONAL_INPUT_VALUE="USERID | USERID for the Resource Owner"

CREATE_ONLY_USER_AND_ONE_INPUT_APP "gw_resource_create.sh" "CREATE RESOURCE" "Create a Resource Account/Mailbox in Post Office: ${POST_OFFICE_IN_UPPER}" "${CREATE_FOLDER_ID}" "0" "RESOURCE NAME" "Conference Room 1" "false" "/^[A-Za-z-_0-9# ]+$/" 
}

function CREATE_APP_CREATE_GROUP_OBJECT()
{
ADDITIONAL_APP_PARAMETER="-o 4"

CREATE_ONE_INPUT_APP "gw_group_create.sh" "CREATE GROUP" "Create a GroupWise Group in Post Office: ${POST_OFFICE_IN_UPPER}" "${CREATE_FOLDER_ID}" "GROUP NAME" "Accounting Group" "false" "/^[A-Za-z-_0-9# ]+$/"
}


#Make Apps

function CREATE_PO_APPS()
{
# UPDATE USER APPS
CREATE_USER_MAILBOX_STATS_CHANGES_FOLDER_APP
CREATE_CIMITRA_TITLE_APP
CREATE_CIMITRA_PHONE_APP
CREATE_CIMITRA_DEPARTMENT_APP
CREATE_CIMITRA_LIST_GROUPS_IN_POST_OFFICE_APP
CREATE_CIMITRA_GROUP_LIST_USERS_APP
CREATE_USER_GROUP_REPORT_APP
CREATE_CIMITRA_GROUP_ADD_USER_APP
CREATE_CIMITRA_GROUP_REMOVE_USER_APP
CREATE_CIMITRA_FIRST_NAME_APP
CREATE_CIMITRA_LAST_NAME_APP
CREATE_CIMITRA_USERID_CHANGE_APP

# FIX USER APPS
CREATE_USER_MAILBOX_SYNC_APP
CREATE_USER_MAILBOX_GWCHECK_STRUCTURE_APP
CREATE_USER_QUICKFINDER_REBUILD_APP

# USER ACCESS APPS
CREATE_USER_MAILBOX_STATS_ACCESS_FOLDER_APP
CREATE_USER_PASSWORD_APP
CREATE_USER_ENABLE_APP
CREATE_USER_DISABLE_APP
CREATE_USER_ACTIVE_APP
CREATE_USER_INACTIVE_APP
CREATE_USER_EXPIRE_APP
CREATE_USER_UNEXPIRE_APP
CREATE_USER_VISIBILITY_APP

# POST OFFICE REPORTS
CREATE_PO_PHONE_REPORT_ALL_USERS
CREATE_PO_PHONE_REPORT_ALL_PHONES
CREATE_PO_PHONE_REPORT_NO_PHONES
CREATE_PO_TITLE_REPORT_ALL_USERS
CREATE_PO_TITLE_REPORT_ALL_TITLES
CREATE_PO_TITLE_REPORT_NO_TITLES
CREATE_PO_DEPARTMENT_REPORT_ALL_USERS
CREATE_PO_DEPARTMENT_REPORT_ALL_DEPARTMENTS
CREATE_PO_DEPARTMENT_REPORT_NO_DEPARTMENTS

# OBJECT CREATION APPS
CREATE_APP_CREATE_USER_OBJECT
CREATE_APP_CREATE_RESOURCE_OBJECT
CREATE_APP_CREATE_GROUP_OBJECT


}

function CREATE_SYSTEM_APPS()
{
# ADMIN SYSTEM REPORTS
CREATE_SYSTEM_PHONE_REPORT_ALL_USERS
CREATE_SYSTEM_PHONE_REPORT_ALL_PHONES
CREATE_SYSTEM_PHONE_REPORT_NO_PHONES
CREATE_SYSTEM_TITLE_REPORT_ALL_USERS
CREATE_SYSTEM_TITLE_REPORT_ALL_TITLES
CREATE_SYSTEM_TITLE_REPORT_NO_TITLES
CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_USERS
CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_DEPARTMENTS
CREATE_SYSTEM_DEPARTMENT_REPORT_NO_DEPARTMENTS
CREATE_SYSTEM_DEPARTMENT_REPORT_ALL_NICKNAMES
}

function CONNECT_TEST()
{

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

{
source ${GW_SCRIPT_SETTINGS_FILE}
} 2> /dev/null

PORT="${CIMITRA_SERVER_PORT}"
ADDRESS="${CIMITRA_SERVER_ADDRESS}"

{
cat < /dev/tcp/${ADDRESS}/${PORT} &
} 2> /dev/null

CONNECTION_PROCESS=$!

declare -i CONNECTION_PROCESS_WORKED=`ps -aux | grep ${CONNECTION_PROCESS} | grep -c "cat"`

if [ $CONNECTION_PROCESS_WORKED -eq 0 ]
then
return 1
else
return 0
fi

}

function DOWNLOAD_AND_INSTALL_CIMITRA_AGENT()
{

CIMITRA_AGENT_BINARY_FILE="/usr/bin/cimagent"

declare -i CIMITRA_AGENT_INSTALLED=`test -f ${CIMITRA_AGENT_BINARY_FILE} ; echo $?`

# echo "CIMITRA_AGENT_INSTALLED = $CIMITRA_AGENT_INSTALLED"

# If an agent isn't installed....
if [ $CIMITRA_AGENT_INSTALLED -eq 1 ]
then

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"
 
ENDPOINT="/agent" 

URL="${BASEURL}${ENDPOINT}" 

# Look for all agents
{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X GET ${URL}`
} 1> /dev/null 2> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}
	

	if [ $CIMITRA_AGENT_IN_SET -eq 0 ]
	then
	AGENT_NAME="${POST_OFFICE_IN_UPPER}"
	else
	AGENT_NAME="${CIMITRA_AGENT_IN_UPPER}"
	fi

	declare -i CIMITRA_AGENT_NAME_EXISTS=`cat ${TEMP_FILE_TWO} | grep -icw "name:${AGENT_NAME}"`

	if [ $CIMITRA_AGENT_NAME_EXISTS -gt 0 ]
	then
	CIMITRA_PAIRED_AGENT_ID=`cat ${TEMP_FILE_TWO} | grep -iwB 1 "name:${AGENT_NAME}" | head -1 | awk -F ":" '{printf $2}'`
	else
	CREATE_PAIRED_CIMITRA_AGENT
	fi		



fi

if [ $CIMITRA_AGENT_INSTALLED -eq 0 ]
then
# echo "AGENT IS INSTALLED...Let's keep checking"
# Determine if the installed Cimitra Agent is actually still registered in Cimitra
CIMITRA_BINARY_AGENT_ID=`${CIMITRA_AGENT_BINARY_FILE} | grep -iA1 "agentid" | tail -1 | awk -F "= " '{printf $2}'`

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"
 
ENDPOINT="/agent" 

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X GET ${URL}`
} 1> /dev/null 2> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

SEARCH_FOR="${CIMITRA_BINARY_AGENT_ID}"

declare -i CIMITRA_AGENT_ID_EXISTS=`cat ${TEMP_FILE_TWO} | grep -icw "_id:${SEARCH_FOR}"`

# echo "CIMITRA_AGENT_ID_EXISTS = $CIMITRA_AGENT_ID_EXISTS"


	if [ $CIMITRA_AGENT_ID_EXISTS -gt 0 ]
	then
	CIMITRA_PAIRED_AGENT_ID=`cat ${TEMP_FILE_TWO} | grep -iw  "_id:${SEARCH_FOR}" | head -1 | awk -F ":" '{printf $2}'`
	CIMITRA_PAIRED_AGENT_NAME=`cat ${TEMP_FILE_TWO} | grep -A 1 ${SEARCH_FOR} | tail -1 | awk -F ":" '{printf $2}'`
	CIMITRA_PAIRED_AGENT_NAME_LOWER=`echo "${CIMITRA_PAIRED_AGENT_NAME}" | tr [A-Z] [a-z]`
	rm ${TEMP_FILE_ONE} 2> /dev/null
	rm ${TEMP_FILE_TWO} 2> /dev/null

		if [ $CIMITRA_AGENT_IN_SET -eq 1 ]
		then
		
			if [ ${CIMITRA_PAIRED_AGENT_NAME_LOWER} == ${CIMITRA_AGENT_IN_LOWER} ]
			then
			echo ""
			echo "Success: The Cimitra Agent is Already Installed"
			echo ""
			return
			fi

		else
		echo ""
		echo "Success: The Cimitra Agent is Already Installed"
		echo ""
		return
		fi
	else

		if [ $CIMITRA_AGENT_IN_SET -eq 0 ]
		then
		AGENT_NAME="${POST_OFFICE_IN_UPPER}"
		else
		AGENT_NAME="${CIMITRA_AGENT_IN_UPPER}"
		fi

	declare -i CIMITRA_AGENT_NAME_EXISTS=`cat ${TEMP_FILE_TWO} | grep -icw "name:${AGENT_NAME}"`
	# echo "CIMITRA_AGENT_NAME_EXISTS = $CIMITRA_AGENT_NAME_EXISTS"


		if [ $CIMITRA_AGENT_NAME_EXISTS -gt 0 ]
		then

			CIMITRA_PAIRED_AGENT_ID=`cat ${TEMP_FILE_TWO} | grep -iwB 1 "name:${AGENT_NAME}" | head -1 | awk -F ":" '{printf $2}'`
		# echo "CIMITRA_PAIRED_AGENT_ID = $CIMITRA_PAIRED_AGENT_ID"
		else
			echo ""
			echo "Process: Replacing the existing Cimitra Agent"
			echo ""
			rm ${TEMP_FILE_ONE} 2> /dev/null
			rm ${TEMP_FILE_TWO} 2> /dev/null
			CREATE_PAIRED_CIMITRA_AGENT
		fi		


	fi

fi

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

DATA="{\"host\": \"${CIMITRA_SERVER_ADDRESS}\",\"port\": \"${CIMITRA_SERVER_PORT}\",\"root\": \"/api\",\"arch\": \"x64\"}" 

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

ENDPOINT="/agent/${CIMITRA_PAIRED_AGENT_ID}/download"

URL="${BASEURL}${ENDPOINT}" 

CIMAGENT_FILE="${TEMP_FILE_DIRECTORY}/cimagent"

# echo "CIMITRA_PAIRED_AGENT_ID = $CIMITRA_PAIRED_AGENT_ID"

# echo "DATA = $DATA"


rm ${CIMAGENT_FILE} 2> /dev/null

echo ""
echo "Process: Downloading the Cimitra Agent File (this may take a little bit...)"
echo ""
echo "-----------------------------------------------------------------------------"
echo ""

curl -k  \
-H "Accept: application/json" \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-H "Cache-Control: no-cache" \
-X POST ${URL} \
-H "Content-Type: application/json" \
--data "${DATA}" -o ${CIMAGENT_FILE} 

echo ""
echo "-----------------------------------------------------------------------------"


declare -i CIMAGENT_FILE_EXISTS=`test -f ${CIMAGENT_FILE} ; echo $?`

if [ $CIMAGENT_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Note: Could not Download the Cimitra Agent File"
return
fi

chmod +x ${CIMAGENT_FILE}

cd ${TEMP_FILE_DIRECTORY}

./cimagent 1> /dev/null 2> /dev/null 

DOWNLOAD_FILE_STATE=`echo $?`

if [ $DOWNLOAD_FILE_STATE -ne 0 ]
then

rm ${CIMAGENT_FILE} 2> /dev/null

BASEURL="http://${CIMITRA_SERVER_API_ADDRESS}:${CIMITRA_SERVER_API_PORT}"

URL="${BASEURL}${ENDPOINT}" 

echo ""
echo "Process: Downloading the Cimitra Agent File (this may take a little bit...)"
echo ""
echo "-----------------------------------------------------------------------------"
echo ""

curl -k  \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X POST ${URL} \
-H "Content-Type: application/json" \
--data "${DATA}" -o ${CIMAGENT_FILE} 

echo ""
echo "-----------------------------------------------------------------------------"

else
echo ""
echo "Success: Downloaded the Cimitra Agent File"

fi

chmod +x ${CIMAGENT_FILE}

./cimagent 1> /dev/null 2> /dev/null 

DOWNLOAD_FILE_STATE=`echo $?`

if [ $DOWNLOAD_FILE_STATE -eq 0 ]
then
./cimagent c

{
cimitra stop 2> /dev/null 
cimitra start  &
} 1> /dev/null 2> /dev/null
else
echo ""
echo "Note: Could not Download the Cimitra Agent File"
echo ""
echo "Task: You may need to Download the Cimitra Agent"
echo ""
fi

}

function REMOVE_FOLDER()
{
FOLDER_IN=$1

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

ENDPOINT="/apps/${FOLDER_IN}"

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X DELETE ${URL}`
} 1> /dev/null 2> /dev/null

}

function REMOVE_ALL_APPS_FROM_FOLDER()
{

FOLDER_IN=$1

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

ENDPOINT="/apps/${FOLDER_IN}/children"

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X GET ${URL}`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

declare -i IDS_EXISTS=`cat ${TEMP_FILE_TWO} | grep -c "_id:"`

BASEURL="https://${CIMITRA_SERVER_ADDRESS}:${CIMITRA_SERVER_PORT}/api"

URL="${BASEURL}${ENDPOINT}" 

if [ $IDS_EXISTS -gt 0 ]
then
rm ${TEMP_FILE_ONE}

cat ${TEMP_FILE_TWO} | grep "_id:" 1> ${TEMP_FILE_ONE}

while read APP_RECORD
do

APP_ID=`echo "${APP_RECORD}" | awk -F ":" '{printf $2}'`

ENDPOINT="/apps/${APP_ID}"

URL="${BASEURL}${ENDPOINT}" 

{
declare RESPONSE=`curl -k ${CURL_OUTPUT_MODE} -H 'Accept: application/json' \
-H "Authorization: Bearer ${CIMITRA_API_SESSION_TOKEN}" \
-X DELETE ${URL}`
} 1> /dev/null 2> /dev/null


done < ${TEMP_FILE_ONE}

fi

rm ${TEMP_FILE_ONE} 2> /dev/null
rm ${TEMP_FILE_TWO} 2> /dev/null

}

function REMOVE_PO_APPS()
{
REMOVE_ALL_APPS_FROM_FOLDER ${USER_FIXES_FOLDER_ID}
REMOVE_FOLDER ${USER_FIXES_FOLDER_ID}

REMOVE_ALL_APPS_FROM_FOLDER ${USER_CHANGES_FOLDER_ID}
REMOVE_FOLDER ${USER_CHANGES_FOLDER_ID}

REMOVE_ALL_APPS_FROM_FOLDER ${USER_ACCESS_FOLDER_ID}
REMOVE_FOLDER ${USER_ACCESS_FOLDER_ID}

REMOVE_ALL_APPS_FROM_FOLDER ${USER_REPORTS_FOLDER_ID}
REMOVE_FOLDER ${USER_REPORTS_FOLDER_ID}

REMOVE_ALL_APPS_FROM_FOLDER ${CREATE_FOLDER_ID}
REMOVE_FOLDER ${CREATE_FOLDER_ID}

REMOVE_FOLDER ${HELPDESK_GROUPWISE_PO_FOLDER_ID}

}

function REMOVE_SYSTEM_APPS()
{
REMOVE_ALL_APPS_FROM_FOLDER ${GROUPWISE_ADMIN_FOLDER_ID}
REMOVE_FOLDER ${GROUPWISE_ADMIN_FOLDER_ID}
REMOVE_ALL_APPS_FROM_FOLDER ${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}
REMOVE_FOLDER ${CIMITRA_GROUPWISE_ROOT_FOLDER_ID}
}


function main()
{

if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi



PROCESS_CIMITRA_SETTINGS
CONFIRM_CORRECT_INPUT
CONNECT_TEST

declare -i CIMITRA_SERVER_TEST=`echo $?`

if [ $CIMITRA_SERVER_TEST -eq 1 ]
then
echo "" 
echo "Error: Could Not Establish Connection to Cimitra Server" 
echo ""
echo "Configure The Script Settings file"
echo "${GW_SCRIPT_SETTINGS_FILE}"
echo ""
echo "Or confirm that the Cimitra Server is up"
echo "And the firewall is properly configured"
echo ""
declare -i CIMITRA_SERVER_ADDRESS_AND_PORT_REQUIRED=1
PROMPT_FOR_SETTINGS
echo ""
echo "Process: Now that you made settings changes, trying again" 
echo ""
# exit 1
fi

ESTABLISH_CIMITRA_API_SESSION

if [ $RUN_CONNECTION_TEST -eq 1 ]
then
echo ""
exit 0
fi

if [ $UNINSTALL_CIMITRA_APP_STRUCTURE -eq 1 ]
then
CREATE_OR_DISOVER_GROUPWISE_FOLDER_STRUCTURE
REMOVE_PO_APPS
	if [ $CREATE_SYSTEM_APPS -eq 0 ]
	then
	REMOVE_SYSTEM_APPS
	fi
echo ""
echo "Success Reversed GroupWise Post Office ${POST_OFFICE_IN_UPPER} Integration"
return
fi

if [ $INSTALL_CIMITRA_AGENT -eq 1 ]
then
DOWNLOAD_AND_INSTALL_CIMITRA_AGENT
fi

CREATE_OR_DISOVER_GROUPWISE_FOLDER_STRUCTURE
CREATE_PO_APPS

if [ $CREATE_SYSTEM_APPS -eq 1 ]
then
CREATE_SYSTEM_APPS
fi

}

main
#!/bin/bash
###########################################
# gw_user_expire.sh                       #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# Allows for a GroupWise Account Expiration Date to be Set

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"

declare -i USERID_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i EXPIRE_DATE_IN_SET=0
declare -i DATE_EPOCH=0


while getopts "d:u:p:hv" opt; do
  case ${opt} in
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    d) EXPIRE_DATE_IN="$OPTARG"
	EXPIRE_DATE_IN_SET=1
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise Account Disable Script"
echo ""
echo "Script usage:   $0 [options]"
echo ""
echo "Example:        $0  -p <post office> -u <GroupWise userid> -d <date formats: 1/4/2020 or epoch: 1578114000>"
echo ""
echo "Example:        $0  -p po1 -u jdoe -d 1/4/2020"
echo ""
echo "Verbose Mode:   $0 -v -p <post office> -u <GroupWise userid> -d <date>"
echo ""
echo "Help:           $0 -h"
echo ""
}


### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}

### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+POST_OFFICE_IN_SET+EXPIRE_DATE_IN_SET

if [ $ALL_SET -ne 3 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}


function PROCESS_DATE_INPUT_VALUES()
{
declare -i IS_NON_EPOCH=`echo "${EXPIRE_DATE_IN}" | grep -c "/"`

if [ $IS_NON_EPOCH -eq 0 ]
then
declare -i EPOCH_LENGTH=`echo "${EXPIRE_DATE_IN}" | wc -c`


	if [ $EPOCH_LENGTH -ne 11 ]
	then
	echo "Error epoch entered: ${EXPIRE_DATE_IN} is not 10 characters in length"
	exit 1
	else
	DATE_EPOCH="${EXPIRE_DATE_IN}"
	return
	fi
fi

declare -i DATE_SLASH_COUNT=`echo "${EXPIRE_DATE_IN}" | tr -d -c '/' | wc -m`

if [ $DATE_SLASH_COUNT -ne 2 ]
then
echo ""
echo "Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The date should look similar to this: 1/4/2020"
echo ""
exit 1
fi

declare -i MONTH_VALUE=`echo "${EXPIRE_DATE_IN}" | awk -F / '{printf $1}'`

if ! [[ "${MONTH_VALUE}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The date should look similar to this: 1/4/2020"
echo ""
exit 1
fi

if [[ ${MONTH_VALUE} -ge 1 && ${MONTH_VALUE} -le 12 ]]
then
:
else
echo ""
echo "Month Value: ${MONTH_VALUE} is not properly formatted."
echo ""
echo "The month value should be a number between 1 and 12"
echo ""
exit 1
fi

declare -i DAY_VALUE=`echo "${EXPIRE_DATE_IN}" | awk -F / '{printf $2}'`

if ! [[ "${DAY_VALUE}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The date should look similar to this: 1/4/2020"
echo ""
exit 1
fi

if [[ ${DAY_VALUE} -ge 1 && ${DAY_VALUE} -le 31 ]]
then
:
else
echo ""
echo "Day Value: ${DAY_VALUE} is not properly formatted."
echo ""
echo "The month value should be a number between 1 and 31"
echo ""
exit 1
fi

declare -i YEAR_VALUE=`echo "${EXPIRE_DATE_IN}" | awk -F / '{printf $3}'`

if ! [[ "${YEAR_VALUE}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The date should look similar to this: 1/4/2020"
echo ""
exit 1
fi

if [[ ${YEAR_VALUE} -ge 2020 && ${YEAR_VALUE} -le 2060 ]]
then
:
else
echo ""
echo "Day Value: ${YEAR_VALUE} is not properly formatted."
echo ""
echo "The year value should be a number such as: 2020"
echo ""
exit 1
fi


case ${MONTH_VALUE} in
1)
MONTH_CHARS="Jan "
MONTH_STRING="January"
declare -i MAX_DAYS="31"
;;
2)
MONTH_CHARS="Feb "
declare -i MAX_DAYS="29"
MONTH_STRING="February"
;;
3)
MONTH_CHARS="Mar "
declare -i MAX_DAYS="31"
MONTH_STRING="March"
;;
4)
MONTH_CHARS="Apr "
declare -i MAX_DAYS="30"
MONTH_STRING="April"
;;
5)
MONTH_CHARS="May "
declare -i MAX_DAYS="31"
MONTH_STRING="May"
;;
6)
MONTH_CHARS="Jun "
declare -i MAX_DAYS="30"
MONTH_STRING="June"
;;
7)
MONTH_CHARS="Jul "
declare -i MAX_DAYS="31"
MONTH_STRING="July"
;;
8)
MONTH_CHARS="Aug "
declare -i MAX_DAYS="31"
MONTH_STRING="August"
;;
9)
MONTH_CHARS="Sep "
declare -i MAX_DAYS="31"
MONTH_STRING="September"
;;
10)
MONTH_CHARS="Oct "
declare -i MAX_DAYS="31"
MONTH_STRING="October"
;;
11)
MONTH_CHARS="Nov "
declare -i MAX_DAYS="30"
MONTH_STRING="November"
;;
12)
MONTH_CHARS="Dec "
declare -i MAX_DAYS="31"
MONTH_STRING="December"
;;
*)
echo ""
echo "Error: Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The date should look similar to this: 1/4/2020"
echo ""
exit 1
;;
esac

if [ ${DAY_VALUE} -gt ${MAX_DAYS} ]
then
echo ""
echo "Error: Date entered: ${EXPIRE_DATE_IN} is not properly formatted."
echo ""
echo "The month of ${MONTH_STRING} only has ${MAX_DAYS} days in it."
echo ""
exit 1
fi

DATE_EPOCH=`date -d "${MONTH_CHARS} ${DAY_VALUE} ${YEAR_VALUE}" +%s`



}

### Primary Function for Account Disabled ###
function SET_ACCOUNT_EXPIRE()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA='{"expirationDate":"'$DATE_EPOCH'000"}'

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

# --- Now use curl to change the value

curl -f ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA 

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
THE_DATE=`date -d @${DATE_EPOCH}`
echo ""
echo "Expiration for Account: ${USERID_IN} Set to: ${THE_DATE}"
echo ""
else
echo ""
echo "Expiraton For Account: ${USERID_IN} Not Set!"
echo ""
fi
}

main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
CONFIRM_CORRECT_INPUT
PROCESS_EXCLUSIONS
GET_EXCLUDE_GROUP_MEMBERSHIP
PROCESS_DATE_INPUT_VALUES
SET_ACCOUNT_EXPIRE
}

main





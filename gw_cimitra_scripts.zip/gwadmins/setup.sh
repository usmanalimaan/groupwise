#!/bin/bash
###########################################
# setup.sh                                #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# Setup script

declare -i SHOW_HELP_SCREEN=0
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare -i GROUP_IN_SET=0
declare -i POST_OFFICE_IN_SET=0

while getopts "hv" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Setup Script"
echo ""
echo "Script usage:   $0 [options]"
echo ""
echo "Example:        $0"
echo ""
echo "Verbose Mode:   $0 -v"
echo ""
echo "Help:           $0 -h"
echo ""
}

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

echo ""
echo "Nothing more to do, you have configured GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
echo "Enjoy!"
echo ""


}

function main()
{

PROCESS_SETTINGS_FILES

}

main

